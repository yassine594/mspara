<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Hengxin || Tableau de bord</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<!-- Data Tables -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/datatables/media/css/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/datatables/extensions/Responsive/css/responsive.bootstrap.min.css')); ?>">

    <!-- Summernote -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/summernote/summernote.css')); ?>">
	<!-- Main Styles -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/styles/style.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css')); ?>">

	<!-- Material Design Icon -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/material-design/css/materialdesignicons.css')); ?>">

	<!-- mCustomScrollbar -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/mCustomScrollbar/jquery.mCustomScrollbar.min.css')); ?>">

	<!-- Waves Effect -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/waves/waves.min.css')); ?>">

	<!-- Sweet Alert -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/sweet-alert/sweetalert.css')); ?>">

	<!-- Percent Circle -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/percircle/css/percircle.css')); ?>">

	<!-- Chartist Chart -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/chart/chartist/chartist.min.css')); ?>">

	<!-- FullCalendar -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/fullcalendar/fullcalendar.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugin/fullcalendar/fullcalendar.print.css')); ?>">
    <?php if(isset($sc)): ?>


    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
    <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/layouts/head.blade.php ENDPATH**/ ?>