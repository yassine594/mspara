<?php $__env->startSection('content'); ?>


<div id="wrapper">
    <div class="main-content">
        <div class="row small-spacing">
            <div class="col-xs-9">
                <div class="box-content card white">
                    <h4 class="box-title">Ajouter un Service</h4>
                    <!-- /.box-title -->
                    <div class="col-md-12">
                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <form action="<?php echo e(route('service.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Titre</label>
                                <input type="text" class="form-control" placeholder="Titre" value="<?php echo e(old('title')); ?>" name="title">
                            </div>


                            <div class="m-t-20">
                                <label for="exampleInputEmail1">Paragraphe</label>

                                <textarea name="description" id="description" class="form-control" maxlength="225" rows="2" placeholder="Paragraphe...."><?php echo e(old('description')); ?></textarea>
                            </div>

                            <div class="m-t-20">
                                <label>Photo</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnail" class="form-control" type="text" name="photo">
                                  </div>
                                <div id="holder" style="margin-top:15px;max-height:100px;"></div>
                            </div>

                            <div class="m-t-20">
                                <label>Document de service (optionnel)</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfmdoc" data-input="thumbnaildoc" data-preview="holderdoc" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnaildoc" class="form-control" type="text" name="doc">
                                  </div>
                                <div id="holderdoc" style="margin-top:15px;max-height:100px;"></div>
                            </div>



                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Status</label>
                                <select class="form-control" name="status">
                                        <option value="active" <?php echo e(old('status')=='active' ? 'selected' : ''); ?>>Active</option>
                                        <option value="inactive" <?php echo e(old('status')=='inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Ajouter</button>
                        </form>
                    </div>
                    <!-- /.card-content -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
<script>
    $('#lfmdoc').filemanager('file');
</script>
<script>
    $(document).ready(function() {
        $('#description').summernote();
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/service/create.blade.php ENDPATH**/ ?>