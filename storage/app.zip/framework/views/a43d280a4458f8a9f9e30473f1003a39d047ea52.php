
<?php if(session('success')): ?>


<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php elseif(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong>Holy guacamole!</strong> You should check in on some of those fields below.
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/layouts/notification.blade.php ENDPATH**/ ?>