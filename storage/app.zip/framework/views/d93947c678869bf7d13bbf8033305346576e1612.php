

<?php $__env->startSection('content'); ?>

<!-- START SECTION PROPERTIES LISTING -->
        <section class="properties-right featured portfolio ho-17 blog pt-5">
            <div class="container">
               <section class="headings-2 pt-0 pb-55">
                    <div class="pro-wrapper">
                        <div class="detail-wrapper-body">
                            <div class="listing-title-bar">

                            </div>
                        </div>
                    </div>
                </section>
                <div class="row">
                    <div class="col-lg-8 col-md-12 blog-pots">
                        <section class="headings-2 pt-0">
                            <div class="pro-wrapper">
                                <div class="detail-wrapper-body">
                                    <div class="listing-title-bar">
                                        <div class="text-heading text-left">
                                            <p class="font-weight-bold mb-0 mt-3"><?php echo e(count($products)); ?> résultats</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="cod-pad single detail-wrapper mr-2 mt-0 d-flex justify-content-md-end align-items-center grid" >
                                    <div class="input-group border rounded input-group-lg w-auto mr-4">
                                        <label class="input-group-text bg-transparent border-0 text-uppercase letter-spacing-093 pr-1 pl-3" for="inputGroupSelect01"><i class="fas fa-align-left fs-16 pr-2"></i>trier par:</label>
                                        <select class="form-control border-0 bg-transparent shadow-none p-0 selectpicker sortby" data-style="bg-transparent border-0 font-weight-600 btn-lg pl-0 pr-3" id="sortBy" name="sortby">
                                            <option selected>Dérnier</option>
                                            <option <?php if(isset($_GET['sort'])&& ($_GET['sort'] == 'titleAsc')): ?>
                                                selected
                                            <?php endif; ?> value="titleAsc">Alphabétique (croissant)</option>
                                            <option <?php if(isset($_GET['sort'])&& ($_GET['sort'] == 'titleDesc')): ?>
                                            selected
                                        <?php endif; ?> value="titleDesc">Alphabétique (décroissant)</option>
                                            <option <?php if(isset($_GET['sort'])&& ($_GET['sort'] == 'priceAsc')): ?>
                                            selected
                                        <?php endif; ?> value="priceAsc">Prix (croissant)</option>
                                            <option <?php if(isset($_GET['sort'])&& ($_GET['sort'] == 'priceDesc')): ?>
                                            selected
                                        <?php endif; ?> value="priceDesc">Prix (décroissant)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" id="product-data">
                            <?php echo $__env->make('frontend.layouts._single-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                        <div class="ajax-load text-center" style="display: none">
                            <img src="<?php echo e(asset('frontend/images/loading.gif')); ?>" style="width: 30%;" >
                        </div>
                        <?php if(count($products)==0): ?>


                            <p>Il n'y a pas de locaux</p>
                        <?php endif; ?>
                    </div>

                    <aside class="col-lg-4 col-md-12 car">
                        <div class="widget">
                            <!-- Search Fields -->
                            <div class="widget-boxed main-search-field">
                                <div class="widget-boxed-header">
                                    <h4>Filtres</h4>
                                </div>
                                <!-- Search Form -->
                                <div class="trip-search">
                                    <form class="form" method="GET" action="<?php echo e($_SERVER['REQUEST_URI']); ?>">

                                        <?php if(isset($_GET['sort'])): ?>
                                            <input type="hidden" name="sort" value="<?php echo e($_GET['sort']); ?>" >
                                        <?php endif; ?>
                                        <!-- Form Lookin for -->
                                        <div class="form-group looking">
                                            <div class="first-select wide">
                                                <div class="main-search-input-item">
                                                    <input type="text" name="search"
                                                      <?php if(isset($_GET['search'])): ?>
                                                      value="<?php echo e($_GET['search']); ?>"
                                                    <?php endif; ?>

                                                    placeholder="Mots clés..." />
                                                </div>
                                            </div>
                                        </div>
                                        <!--/ End Form Lookin for -->

                                        <!-- Form Categories -->
                                        <input type="hidden" id="search-type1" name="search_conditions" value="<?php if(isset($_GET['search_conditions'])): ?><?php echo e($_GET['search_conditions']); ?><?php endif; ?>">
                                        <div class="form-group categories">
                                            <div class="nice-select form-control wide" tabindex="0">
                                                <span id="span_fond">Conditions (
                                                    <?php if(isset($_GET['search_conditions'])): ?>
                                                        <?php if($_GET['search_conditions']=='fdc'): ?>
                                                        Fond de commerce
                                                         <?php elseif($_GET['search_conditions']=='dab'): ?>
                                                         Droit au bail
                                                         <?php elseif($_GET['search_conditions']=='mc'): ?>
                                                         Murs commerciaux
                                                         <?php elseif($_GET['search_conditions']=='lp'): ?>
                                                         Location pure
                                                        <?php else: ?>
                                                            Tous
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                    Tous
                                                    <?php endif; ?>

                                                    )</span>

                                                <ul id="selType1" class="list">
                                                    <li value="" class="option
                                                    <?php if(!isset($_GET['search_conditions'])): ?> selected <?php endif; ?>
                                                    <?php if(isset($_GET['search_conditions']) && ($_GET['search_conditions'] == "")): ?> selected  <?php endif; ?>
                                                    " >Tous</li>
                                                    <li value="fdc" class="option
                                                    <?php if(isset($_GET['search_conditions']) && ($_GET['search_conditions'] == "fdc")): ?> selected  <?php endif; ?>
                                                    " >Fond de commerce</li>
                                                    <li value="dab" class="option
                                                    <?php if(isset($_GET['search_conditions']) && ($_GET['search_conditions'] == "dab")): ?> selected  <?php endif; ?>
                                                    ">Droit au bail</li>
                                                    <li value="mc" class="option
                                                    <?php if(isset($_GET['search_conditions']) && ($_GET['search_conditions'] == "mc")): ?> selected  <?php endif; ?>
                                                    ">Mure commerciaux</li>
                                                    <li value="lp" class="option
                                                    <?php if(isset($_GET['search_conditions']) && ($_GET['search_conditions'] == "lp")): ?> selected  <?php endif; ?>
                                                    ">Location pure</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!--/ End Form Categories -->
                                        <!-- Form Property Status -->
                                        <input type="hidden" id="search-type" name="search_type" value="<?php if(isset($_GET['search_type'])): ?><?php echo e($_GET['search_type']); ?><?php endif; ?>">
                                        <div class="form-group categories">
                                            <div class="nice-select form-control wide" tabindex="0">
                                                <span id="span_type"><?php if(isset($_GET['search_type'])): ?>
                                                    <?php if($_GET['search_type']=='sale'): ?>
                                                    à vendre
                                                     <?php elseif($_GET['search_type']=='rent'): ?>
                                                     à louer
                                                    <?php else: ?>
                                                        Tous
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                Tous
                                                <?php endif; ?></span>

                                                <ul id="selType" class="list">
                                                    <li value="" class="option  <?php if(!isset($_GET['search_type'])): ?> selected <?php endif; ?>
                                                    <?php if(isset($_GET['search_type']) && ($_GET['search_type'] == "")): ?> selected  <?php endif; ?>" >Tous</li>
                                                    <li value="sale" class="option <?php if(isset($_GET['search_type']) && ($_GET['search_type'] == "sale")): ?> selected  <?php endif; ?>" >à vendre</li>
                                                    <li value="rent" class="option <?php if(isset($_GET['search_type']) && ($_GET['search_type'] == "rent")): ?> selected  <?php endif; ?>">à louer</li>
                                                </ul>
                                            </div>
                                        </div>


                                        <!--/ End Form Property Status -->
                                        <div class="widget price mb-30" style="margin-bottom: 28px;padding-top: 162px;">
                                            <label>Surface</label>
                                            <br>
                                            <?php if(isset($_GET['surface_range'])): ?>
                                            <?php
                                                $get_surf = explode('-',$_GET['surface_range']);
                                                $min_surface_get = $get_surf[0];
                                                $max_surface_get = $get_surf[1];
                                            ?>


                                            <?php endif; ?>
                                            <div class="widget-desc">
                                                <div class="slider-range">
                                                    <div id="slider-range" data-min="<?php echo e(\App\Models\Product::min('surface')); ?>" data-max="<?php echo e(\App\Models\Product::max('surface')); ?>" data-unit="m²" class="slider-range-surface ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all"
                                                    data-value-min="<?php if(isset($min_surface_get)): ?><?php echo e($min_surface_get); ?><?php else: ?><?php echo e(\App\Models\Product::min('surface')); ?><?php endif; ?>"

                                                    data-value-max="<?php if(isset($max_surface_get)): ?><?php echo e($max_surface_get); ?><?php else: ?><?php echo e(\App\Models\Product::max('surface')); ?><?php endif; ?>" data-label-result="Surface:">
                                                        <div class="ui-slider-range ui-widget-header ui-corner-all"></div>
                                                        <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                                        <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                                    </div>
                                                    <br>
                                                    <div class="range-price">Surface: m² <?php if(isset($min_surface_get)): ?><?php echo e($min_surface_get); ?><?php else: ?><?php echo e(\App\Models\Product::min('surface')); ?><?php endif; ?> - m² <?php if(isset($max_surface_get)): ?><?php echo e($max_surface_get); ?><?php else: ?><?php echo e(\App\Models\Product::max('surface')); ?><?php endif; ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="widget price mb-30" style="margin-bottom: 28px;">
                                            <label>Prix</label>
                                            <br>
                                            <?php if(isset($_GET['price_range'])): ?>
                                            <?php
                                                $get_pr = explode('-',$_GET['price_range']);
                                                $min_price_get = $get_pr[0];
                                                $max_price_get = $get_pr[1];
                                            ?>


                                            <?php endif; ?>
                                            <div class="widget-desc">
                                                <div class="slider-range">
                                                    <div id="slider-range" data-min="<?php echo e(\App\Models\Product::min('price')); ?>" data-max="<?php echo e(\App\Models\Product::max('price')); ?>" data-unit="€" class="slider-range-price ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" data-value-min="<?php if(isset($min_price_get)): ?><?php echo e($min_price_get); ?><?php else: ?><?php echo e(\App\Models\Product::min('price')); ?><?php endif; ?>" data-value-max="<?php if(isset($max_price_get)): ?><?php echo e($max_price_get); ?><?php else: ?><?php echo e(\App\Models\Product::max('price')); ?><?php endif; ?>" data-label-result="Prix:">
                                                        <div class="ui-slider-range ui-widget-header ui-corner-all"></div>
                                                        <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                                        <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                                    </div>
                                                    <br>
                                                    <div class="range-price">Prix: € <?php if(isset($min_price_get)): ?><?php echo e($min_price_get); ?><?php else: ?><?php echo e(\App\Models\Product::min('price')); ?><?php endif; ?> - € <?php if(isset($max_price_get)): ?><?php echo e($max_price_get); ?><?php else: ?><?php echo e(\App\Models\Product::max('price')); ?><?php endif; ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- More Search Options -->
                                <a href="#" style="color: #f55d2c;" class="more-search-options-trigger margin-bottom-10 margin-top-30" data-open-title="Spécialité commerciale" data-close-title="Spécialité commerciale"></a>

                                <div class="more-search-options relative">
                                    <!-- Checkboxes -->
                                    <div class="checkboxes one-in-row margin-bottom-10">
                                        <?php $__currentLoopData = $speciality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input id="check-<?php echo e($sp->id); ?>" value="<?php echo e($sp->id); ?>" checked type="checkbox" name="speciality[]">
                                        <label for="check-<?php echo e($sp->id); ?>"><?php echo e($sp->title); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                    <!-- Checkboxes / End -->
                                </div>
                                <!-- More Search Options / End -->
                                        <div class="col-lg-12 no-pds">
                                            <div class="at-col-default-mar">
                                                <input type="hidden" id="price_range" name="price_range" value="<?php if(isset($_GET['price_range'])): ?><?php echo e($_GET['price_range']); ?><?php else: ?><?php echo e(\App\Models\Product::min('price')); ?>-<?php echo e(\App\Models\Product::max('price')); ?><?php endif; ?>">
                                                <input type="hidden" id="surface_range" name="surface_range" value="<?php if(isset($_GET['surface_range'])): ?><?php echo e($_GET['surface_range']); ?><?php else: ?><?php echo e(\App\Models\Product::min('surface')); ?>-<?php echo e(\App\Models\Product::max('surface')); ?><?php endif; ?>">

                                                <button class="btn btn-default hvr-bounce-to-right" type="submit">Filtrer</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>


                                <!-- Price Fields -->



                            </div>
                            <div class="widget-boxed mt-5">
                                <div class="widget-boxed-header mb-5">
                                    <h4>Recommandations</h4>
                                </div>
                                <div class="widget-boxed-body">
                                    <div class="slick-lancers">

                                    <?php $__currentLoopData = $randomproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $photos = explode(",",$rand->photo);
                                    ?>
                                        <div class="agents-grid mr-0">
                                            <div class="listing-item compact">
                                                <a href="<?php echo e(route('product.detail',$rand->slug)); ?>" class="listing-img-container">
                                                    <div class="listing-badges">
                                                        <span class="featured"><?php if($rand->conditions == 'rent'): ?>
                                                            €<?php echo e(number_format($rand->price)); ?>/mois
                                                            <?php else: ?>
                                                            €<?php echo e(number_format($rand->price)); ?>

                                                        <?php endif; ?></span>
                                                        <span><?php if($rand->conditions == 'rent'): ?>
                                                            à louer
                                                            <?php else: ?>
                                                            à vendre
                                                        <?php endif; ?></span>
                                                    </div>
                                                    <div class="listing-img-content">
                                                        <span class="listing-compact-title"><?php echo e($rand->title); ?> <i><?php echo e(\App\Models\category::where('id',$rand->cat_id)->value('title')); ?></i></span>

                                                    </div>
                                                    <img src="<?php echo e($photos[0]); ?>" alt="<?php echo e($rand->title); ?>">
                                                </a>
                                            </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-boxed mt-5">
                                <div class="widget-boxed-header">
                                    <h4>Dérniers Annonces</h4>
                                </div>
                                <div class="widget-boxed-body">
                                    <div class="recent-post">
                                        <?php $__currentLoopData = $recentproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $photos = explode(",",$recent->photo);
                                        ?>
                                        <div class="recent-main mb-2">
                                            <div class="row">
                                                <div class="col-lg-5">
                                            <div class="recent-img">
                                                <a href="<?php echo e(route('product.detail',$recent->slug)); ?>"><img style="object-fit: cover;width: 354px;height: 100px;" src="<?php echo e($photos[0]); ?>" alt="<?php echo e($recent->title); ?>"></a>
                                            </div>
                                        </div>
                                        <div class="col-lg-7">
                                            <div class="info-img">
                                                <a href="<?php echo e(route('product.detail',$recent->slug)); ?>">
                                                    <h6 title="<?php echo e($recent->title); ?>"><?php echo e(substr($recent->title,0,50)); ?>...</h6></a>
                                                <p><?php if($recent->conditions == 'rent'): ?>
                                                    €<?php echo e(number_format($recent->price)); ?>/mois
                                                    <?php else: ?>
                                                    €<?php echo e(number_format($recent->price)); ?>

                                                <?php endif; ?></p>
                                            </div>
                                        </div>
                                        </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                </div>
                            </div>

                        </div>
                    </aside>
                </div>
            </div>
        </section>
        <!-- END SECTION PROPERTIES LISTING -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('upscripts'); ?>
<script src="<?php echo e(asset('frontend/js/search.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/slick4.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
    $('#sortBy').change(function(){
        var sort=$('#sortBy').val();

        var get_fiter ='<?php if(isset($_GET['search'])): ?>&search=<?php echo $_GET['search']?><?php endif; ?>';
        get_fiter +='<?php if(isset($_GET['search_conditions'])): ?>&search_conditions=<?php echo $_GET['search_conditions']?><?php endif; ?>';
        get_fiter +='<?php if(isset($_GET['search_type'])): ?>&search_type=<?php echo $_GET['search_type']?><?php endif; ?>';
        get_fiter +='<?php if(isset($_GET['price_range'])): ?>&price_range=<?php echo $_GET['price_range']?><?php endif; ?>';
        get_fiter +='<?php if(isset($_GET['surface_range'])): ?>&surface_range=<?php echo $_GET['surface_range']?><?php endif; ?>';

        get_fiter +="<?php if (isset($_GET['speciality'])){ foreach($_GET['speciality'] as $sps){ echo '&speciality[]='.$sps; } }?>";



        window.location="<?php echo e(url(''.$route.'')); ?>/<?php echo e($categories->slug); ?>?sort="+sort+get_fiter;
    });
    </script>
<script>
    function loadmoreData(page) {
        $.ajax({
            url: '?page='+page,
            type: 'GET',
            beforeSend: function () {
                $('.ajax-load').show();
            },
        }).done(function(data){

            if(data.html == ''){
                $('.ajax-load').html('');
                return;
            }
            $('.ajax-load').hide();
            $('#product-data').append(data.html);
        }).fail(function(jqXHR, ajaxOptions, thrownError) {
            console.log('Somethong went wrong!! please try again');
        });
    }
    var page=1;
    $(window).scroll(function () {
        if($(window).scrollTop() +$(window).height()+420>=$(document).height()){
            page ++;
            loadmoreData(page);
        }
    });

    // :: Price Range Code

    $('.slider-range-price').each(function () {
        var min = $(this).data('min'),
            max = $(this).data('max'),
            unit = $(this).data('unit'),
            value_min = $(this).data('value-min'),
            value_max = $(this).data('value-max'),
            label_result = $(this).data('label-result'),
            t = $(this);
        $(this).slider({
            range: true,
            min: min,
            max: max,
            values: [value_min, value_max],
            slide: function (event, ui) {
                var result = label_result + " " + unit + ui.values[0] + ' - ' + unit + ui.values[1];
                t.closest('.slider-range').find('.range-price').html(result);
               // $('#amount').val(ui.values[0]+"-"+ui.values[1]);
                $('#price_range').val(ui.values[0]+"-"+ui.values[1]);
            }
        });
    });
    $('.slider-range-surface').each(function () {
        var min = $(this).data('min'),
            max = $(this).data('max'),
            unit = $(this).data('unit'),
            value_min = $(this).data('value-min'),
            value_max = $(this).data('value-max'),
            label_result = $(this).data('label-result'),
            t = $(this);
        $(this).slider({
            range: true,
            min: min,
            max: max,
            values: [value_min, value_max],
            slide: function (event, ui) {
                var result = label_result + " " + unit + ui.values[0] + ' - ' + unit + ui.values[1];
                t.closest('.slider-range').find('.range-price').html(result);
               // $('#amount').val(ui.values[0]+"-"+ui.values[1]);
                $('#surface_range').val(ui.values[0]+"-"+ui.values[1]);
            }
        });
    });


</script>
<script>
    //Assign the value
$("#selType li").click(function(){
$("#search-type").val($(this).attr("value"));

    if($(this).attr("value") == 'sale'){
        $("#span_type").html("à vendre");

    }
    if($(this).attr("value") == 'rent'){
        $("#span_type").html("à louer");

    }
    if($(this).attr("value") == ''){
        $("#span_type").html("Tous");
    }

});

    //Assign the value
    $("#selType1 li").click(function(){
$("#search-type1").val($(this).attr("value"));

if($(this).attr("value") == 'fdc'){
    $("#span_fond").html("Conditions (Fond de commerce)");

}
if($(this).attr("value") == 'dab'){
    $("#span_fond").html("Conditions (Droit au bail)");

}
if($(this).attr("value") == 'mc'){
    $("#span_fond").html("Conditions (Murs commerciaux)");

}
if($(this).attr("value") == 'lp'){
    $("#span_fond").html("Conditions (Location pure)");

}
if($(this).attr("value") == ''){
    $("#span_fond").html("Conditions (Tous)");

}

});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/pages/product/product-category.blade.php ENDPATH**/ ?>