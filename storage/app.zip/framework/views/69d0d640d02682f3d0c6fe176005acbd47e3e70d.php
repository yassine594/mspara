
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="th-18 inner-pages">
    <!-- Wrapper -->
    <div id="wrapper">

    <!-- Header Area -->
<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header Area End -->

<?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Area -->
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Area -->

<?php echo $__env->make('frontend.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- Wrapper / End -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>