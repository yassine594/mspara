

<?php $__env->startSection('content'); ?>

<!-- START SECTION BLOG -->
<section class="blog-section" style="padding-top: 10rem;">
    <div class="container">
        <div class="news-wrap">
            <div class="row" id="product-data">
                <?php echo $__env->make('frontend.layouts._single-blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="ajax-load text-center" style="display: none">
                <img src="<?php echo e(asset('frontend/images/loading.gif')); ?>" style="width: 30%;" >
            </div>
        </div>

    </div>
</section>
<!-- END SECTION BLOG -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    function loadmoreData(page) {
        $.ajax({
            url: '?page='+page,
            type: 'GET',
            beforeSend: function () {
                $('.ajax-load').show();
            },
        }).done(function(data){

            if(data.html == ''){
                $('.ajax-load').html('');
                return;
            }
            $('.ajax-load').hide();
            $('#product-data').append(data.html);
        }).fail(function(jqXHR, ajaxOptions, thrownError) {
            console.log('Somethong went wrong!! please try again');
        });
    }
    var page=1;
    $(window).scroll(function () {
        if($(window).scrollTop() +$(window).height()+420>=$(document).height()){
            page ++;
            loadmoreData(page);
        }
    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/pages/actualite.blade.php ENDPATH**/ ?>