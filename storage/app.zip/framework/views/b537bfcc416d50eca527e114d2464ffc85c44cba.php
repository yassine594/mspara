 <!-- START FOOTER -->
 <footer class="first-footer">
    <div class="top-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="netabout">
                        <a href="<?php echo e(route('home')); ?>" class="logo">
                            <img style="width: 40%" src="<?php echo e(asset('frontend/images/logo-hengxin-white.svg')); ?>" alt="netcom">
                        </a>
                        <p><?php echo e(filter_var(substr(get_setting('content'),0,95),FILTER_SANITIZE_STRING)); ?>...</p>
                    </div>
                    <div class="contactus">
                        <ul>
                            <li>
                                <div class="info">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                    <p class="in-p"><?php echo e(get_setting('address')); ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="info">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                    <p class="in-p"><?php echo e(get_setting('phone')); ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="info">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    <p class="in-p ti"><?php echo e(get_setting('email')); ?></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="navigation">
                        <h3>Plan de site</h3>
                        <div class="nav-footer">
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                                <li><a href="<?php echo e(route('tous.locaux')); ?>">Tous locaux</a></li>
                                <li><a href="<?php echo e(route('blog.list')); ?>">Actualités</a></li>
                                <li><a href="<?php echo e(route('home')); ?>">À-propos</a></li>
                                <li class="no-mgb"><a href="<?php echo e(route('home')); ?>">Contact</a></li>
                            </ul>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget">
                        <h3>Actualités</h3>
                        <div class="twitter-widget contuct">
                            <div class="twitter-area">
                                <?php $__currentLoopData = \App\Models\Blog::where('status','active')->orderBy('id', 'DESC')->limit(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-item">
                                    <div class="icon-holder">
                                        <i class="fas fa-blog" aria-hidden="true"></i>
                                    </div>
                                    <div class="text">
                                        <h5><a href="<?php echo e(route('blog.detail',$footer_blogs->slug)); ?>">@Hengxin</a> <?php echo e($footer_blogs->title); ?></h5>
                                        <h4><?php
                                            $date = date('Y-m-d',strtotime($footer_blogs->updated_at));
                                            setlocale (LC_TIME, 'fr_FR.utf8','fra');
                                            echo (strftime("%A %d %B",strtotime($date)));
                                        ?></h4>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="newsletters">
                        <h3>Newsletters</h3>
                        <p>Inscrivez-vous à notre newsletter pour obtenir les dernières mises à jour et offres. Abonnez-vous pour recevoir des nouvelles dans votre boîte de réception.</p>
                    </div>
                    <div class="bloq-email form-inline">
                        <label for="subscribeEmail" class="error"></label>
                        <div class="email news_data">
                            <input class="news_id" type="email" name="email" placeholder="Entrez Votre Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="submit" class="add-to-news-btn" value="Abonnez">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="second-footer">
        <div class="container">
            <p>Made with&nbsp; <img src="<?php echo e(asset('frontend/images/heart-icon.png')); ?>" alt="heart-icon" width="17" height="17">&nbsp; By <a style="color: white;" href="https://tounesconnect.com/">TounesConnect © 2021 All Rights Reserved</a></p>
            <ul class="netsocials">
                <?php if(get_setting('facebook') != "#"): ?>
                <li><a href="<?php echo e(get_setting('facebook')); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <?php endif; ?>
                <?php if(get_setting('linkedin') != "#"): ?>
                <li><a href="<?php echo e(get_setting('linkedin')); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                <?php endif; ?>
                <?php if(get_setting('instagram') != "#"): ?>
                <li><a href="<?php echo e(get_setting('instagram')); ?>"><i class="fab fa-instagram"></i></a></li>
                <?php endif; ?>
                <?php if(get_setting('twitter') != "#"): ?>
                <li><a href="<?php echo e(get_setting('twitter')); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <?php endif; ?>
                <?php if(get_setting('youtube') != "#"): ?>
                <li><a href="<?php echo e(get_setting('youtube')); ?>"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                <?php endif; ?>
            </ul>

        </div>
    </div>

</footer>

<a data-scroll href="#wrapper" class="go-up"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
<!-- END FOOTER -->
<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>