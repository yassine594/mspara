<?php $__env->startSection('content'); ?>


<div id="wrapper">
    <div class="main-content">
        <div class="row small-spacing">
            <div class="col-xs-9">
                <div class="box-content card white">
                    <h4 class="box-title">Ajouter gamme</h4>
                    <!-- /.box-title -->
                    <div class="col-md-12">

                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <form action="<?php echo e(route('gamme.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nom</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nom" value="<?php echo e(old('title')); ?>" name="title">
                            </div>


                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Categories</label>
                                <select id="cat_id" class="form-control" name="cat_id" required>
                                    <option value="">--Categorie Parente--</option>
                                    <?php $__currentLoopData = \App\Models\Category::where('is_parent',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(old('cat_id')==$cat->id? 'selected' : ''); ?>><?php echo e($cat->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div id="child_cat_div" class="form-group margin-bottom-20 display-none">
                                <label for="exampleInputEmail1">Sous-Catégories</label>
                                <select id="child_cat_id" class="form-control" name="child_cat_id" required>

                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Ajouter</button>
                        </form>
                    </div>
                    <!-- /.card-content -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script>

        $("#cat_id").change(function(){


                var cat_id=$(this).val();


                if(cat_id != null){
                    //alert(cat_id);
                    $.ajax({
                        url:"/admin/localisation/"+cat_id+"/child",
                        type:"POST",
                        data:{
                            _token:"<?php echo e(csrf_token()); ?>",
                            cat_id:cat_id
                        },
                        success:function(response){
                            var html_option = "";
                            if(response.status){
                           //alert(cat_id);
                              $('#child_cat_div').removeClass('display-none');
                              $.each(response.data,function(id,title){
                                html_option += "<option value='"+id+"'>"+title+"</option>";
                              });
                            }else{
                                $('#child_cat_div').addClass('display-none');

                            }
                            $('#child_cat_id').html(html_option);

                        }
                    });
                }
        });
    if(child_cat_id != null){
        $('#cat_id').change();
    }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/gamme/create.blade.php ENDPATH**/ ?>