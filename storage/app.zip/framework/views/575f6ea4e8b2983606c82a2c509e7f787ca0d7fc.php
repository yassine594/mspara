<?php $__env->startSection('content'); ?>
 <!-- Page Title -->
 <section class="page-title" style="background:black;">
    <div class="auto-container">
        <div class="content-box" style="padding: 63px 0px;">
            <div class="content-wrapper">

            </div>
        </div>
    </div>
</section>

<!-- shop-details -->
<section class="shop-details">
    <div class="auto-container">
        <div class="product-details-content">
            <div class="row clearfix">
                <div class="col-lg-6">
                    <div class="products-carousel">
                        <div class="single-product-view">
                            <div class="swiper-container product-content wow fadeInUp" data-wow-delay="300ms">
                                <div class="swiper-wrapper">
                                    <?php
                                        $photos = explode(",",$product->photo)
                                    ?>
                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="image"><img src="<?php echo e($photo); ?>" alt=""></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </div>
                        </div>
                        <div class="product-thumbs-wrapper">
                            <!-- Swiper -->
                            <div class="swiper-container product-thumbs">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="author-thumb"><img src="<?php echo e($photo); ?>" alt=""></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 content-column">
                    <div class="product-details">
                        <div class="title-box">
                            <h3><?php echo e($product->title); ?></h3>
                        </div>
                        <div class="text">
                            <ul class="category clearfix">
                                <li>Categories:</li>
                                <li><a><?php echo e(\App\Models\Category::where('id',$product->cat_id)->value('title')); ?></a></li>
                                <li>
                                    <a href="<?php echo e(route('local.ville',\App\Models\Category::where('id',$product->child_cat_id)->value('slug'))); ?>"><?php echo e(\App\Models\Category::where('id',$product->child_cat_id)->value('title')); ?></a>
                                </li>
                            </ul>
                            <p><?php echo $product->description; ?></p>
                        </div>

                        <div class="share-option">
                            <p>Partager Sur :</p>


                            <!-- AddToAny BEGIN -->
                            <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                                <a class="a2a_button_facebook"></a>
                                <a class="a2a_button_twitter"></a>
                                <a class="a2a_button_linkedin"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- shop-details end -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('upscripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/pages/product/product-detail.blade.php ENDPATH**/ ?>