<?php $__env->startSection('content'); ?>


<div class="main-content">
<div class="col-lg-12">
    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<h4 class="box-title"><a class="btn btn-secondary" href="<?php echo e(route('equipe.create')); ?>" ><i class="fa fa-plus-circle"></i> Ajouter Membre</a></h4>
    <table class="table table-striped table-bordered display" style="width:100%">
        <thead>
            <tr>
                <th>S.N</th>
                <th>Photo</th>
                <th>Membre d'équipe</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>S.N</th>
                <th>Photo</th>
                <th>Membre d'équipe</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                <tr>
                    <td><?php echo e($loop->iteration); ?></td>

                    <td>
                        <?php if($item->photo != NULL): ?>
                        <img src="<?php echo e($item->photo); ?>" alt="<?php echo e($item->title); ?>" style="width:100px;" />
                        <?php else: ?>
                        Il n'y a pas de photo
                        <?php endif; ?>
                    </td>
                    <td>
                      <p><i class="fa fa-user"></i> <?php echo e($item->title); ?></p>
                    <p><i class="fa fa-briefcase"></i> <?php echo e($item->post); ?></p>
                    <p><i class="fa fa-envelope"></i> <?php echo e($item->email); ?></p>
                    <p><i class="fa fa-phone"></i> <?php echo e($item->phone); ?></p>

                    <p><i class="fa fa-facebook"></i> <?php echo e($item->fb); ?></p>
                    </td>
                    <td>
                        <div class="switch success">

                           <input name="toogle" value="<?php echo e($item->id); ?>" type="checkbox" <?php echo e($item->status=='active' ? 'checked': ''); ?> id="switch-<?php echo e($item->id); ?>">
                            <label for="switch-<?php echo e($item->id); ?>">active</label>
                        </div>
                    </td>
                    <td>

                    <form action="<?php echo e(route('equipe.destroy',$item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="button" data-id="<?php echo e($item->id); ?>" class="float-left dltBtn btn btn-danger btn-sm waves-effect waves-light" style="color:#fff;background-color:#000;"><i class="fa fa-trash" aria-hidden="true"></i></button>
                    </form>

                        <a class="float-left" href="<?php echo e(route('equipe.edit',$item->id)); ?>"><i class="btn btn-warning btn-sm waves-effect waves-light fas fa-pencil-alt" aria-hidden="true"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.dltBtn').click(function(e){
            var form=$(this).closest('form');
            var dataID=$(this).data('id');
            e.preventDefault();

            swal({
                title: "Êtes-vous sûr?",
                text: "Une fois supprimé, vous ne pourrez pas récupérer ce membre!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    form.submit();
                    swal("Poof! Votre membre a été supprimée!", {
                    icon: "success",
                    });
                } else {
                    swal("Votre membre n'est pas supprimée!");
                }
                });
        });
</script>

    <script>
        $('input[name=toogle]').change(function(){
            var mode = $(this).prop('checked');
            var id = $(this).val();
            //alert(id);
            $.ajax({
                url:"<?php echo e(route('equipe.status')); ?>",
                type:"POST",
                data:{
                    _token:'<?php echo e(csrf_token()); ?>',
                    mode:mode,
                    id:id,
                },
                success:function(response){
                    if(response.status){
                        alert(response.msg);
                    }
                    else{
                        alert('Please try again!');
                    }
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/team/index.blade.php ENDPATH**/ ?>