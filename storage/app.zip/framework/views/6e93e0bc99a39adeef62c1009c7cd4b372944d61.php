

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(\App\Models\Category::where(['id' => $item->cat_id])->value('status') == 'active'): ?>
<?php if(\App\Models\Brand::where(['id' => $item->brand_id])->value('status') == 'active'): ?>


<?php
    $photos = explode(",",$item->photo);
?>
<div class="col-lg-4 col-md-6 shop-block">
    <div class="inner-box">
        <div class="image"><a href="<?php echo e(route('product.detail',$item->slug)); ?>"><img src="<?php echo e($item->photo); ?>" alt=""></a></div>
        <div class="content-upper">
            <h4><a href="<?php echo e(route('product.detail',$item->slug)); ?>"><?php echo e($item->title); ?></a></h4>

        </div>
        <div class="bottom-content" style="padding: 13%;">

            <div class="link"><a href="<?php echo e(route('product.detail',$item->slug)); ?>"><i class="flaticon-arrow-1"></i></a></div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/layouts/_single-product.blade.php ENDPATH**/ ?>