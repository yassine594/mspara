


<?php $__env->startSection('content'); ?>


<div id="wrapper">
    <div class="main-content">
        <div class="row small-spacing">
            <div class="col-xs-9">
                <div class="box-content card white">
                    <h4 class="box-title">Ajouter local</h4>
                    <!-- /.box-title -->
                    <div class="col-md-12">

                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <form action="<?php echo e(route('local.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nom</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nom" value="<?php echo e(old('title')); ?>" name="title">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Réference</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Réference" value="<?php echo e(old('ref')); ?>" name="ref">
                            </div>
                            <div class="m-t-20">
                                <label>Photos</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnail" class="form-control" type="text" name="photo">
                                  </div>
                                <div id="holder" style="margin-top:15px;max-height:100px;"></div>
                            </div>

                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Specialité</label>
                                <select class="form-control" name="brand_id">
                                    <option value="">--Specialité--</option>
                                    <?php $__currentLoopData = \App\Models\Brand::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id')==$brand->id? 'selected' : ''); ?>><?php echo e($brand->title); ?></option>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Gouvernerat</label>
                                <select id="cat_id" class="form-control" name="cat_id">
                                    <option value="">--Gouvernerat--</option>
                                    <?php $__currentLoopData = \App\Models\Category::where('is_parent',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(old('cat_id')==$cat->id? 'selected' : ''); ?>><?php echo e($cat->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div id="child_cat_div" class="form-group margin-bottom-20 display-none">
                                <label for="exampleInputEmail1">Délégation</label>
                                <select id="child_cat_id" class="form-control" name="child_cat_id">

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Adresse</label>
                                <input type="text" class="form-control" placeholder="Adresse" value="<?php echo e(old('address')); ?>" name="address">
                            </div>

                            <div class="m-t-20">
                                <label for="exampleInputEmail1">Description</label>

                                <textarea name="description" id="description" class="form-control" maxlength="225" rows="2" placeholder="Write some text...."><?php echo e(old('description')); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Surface</label>
                                <input type="number" class="form-control" placeholder="Surface en m²" value="<?php echo e(old('surface')); ?>" name="surface">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Facade</label>
                                <input type="number" class="form-control" placeholder="facade en m²" value="<?php echo e(old('facade')); ?>" name="facade">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Rez de chaussée</label>
                                <input type="number" class="form-control" placeholder="rez de chaussée en m²" value="<?php echo e(old('rdc')); ?>" name="rdc">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Premiére étage</label>
                                <input type="number" class="form-control" placeholder="Premiére étage en m²" value="<?php echo e(old('petage')); ?>" name="petage">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Prix</label>
                                <input type="number" step="any" class="form-control" placeholder="Price" value="<?php echo e(old('price')); ?>" name="price">
                            </div>
                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Type</label>
                                <select class="form-control" name="conditions">
                                    <option value="">--Type--</option>
                                        <option value="sale" <?php echo e(old('conditions')=='sale' ? 'selected' : ''); ?>>à vendre</option>
                                        <option value="rent" <?php echo e(old('conditions')=='rent' ? 'selected' : ''); ?>>à louer</option>

                                </select>
                            </div>
                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Conditions</label>
                                <select class="form-control" name="fond">
                                    <option value="">--Conditions--</option>
                                        <option value="fdc" <?php echo e(old('fond')=='fdc' ? 'selected' : ''); ?>>Fond de commerce</option>
                                        <option value="dab" <?php echo e(old('fond')=='dab' ? 'selected' : ''); ?>>Droit au bail</option>
                                        <option value="mc" <?php echo e(old('fond')=='mc' ? 'selected' : ''); ?>>Mur commerciaux</option>
                                        <option value="lp" <?php echo e(old('fond')=='lp' ? 'selected' : ''); ?>>Location pur</option>

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Lien de video (Optionnel)</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Lien de video" value="<?php echo e(old('video')); ?>" name="video">
                            </div>
                            <div class="form-group">
                                <label >Date de disponibilité</label>
                                <input type="date" class="form-control" value="<?php echo e(old('date_d')); ?>" name="date_d">
                            </div>
                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Status</label>
                                <select class="form-control" name="status">
                                        <option value="active" <?php echo e(old('status')=='active' ? 'selected' : ''); ?>>Active</option>
                                        <option value="inactive" <?php echo e(old('status')=='inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>

                            <div class="form-group margin-bottom-20">
                                <label for="exampleInputEmail1">Extraction</label>
                                <select class="form-control" name="extraction">

                                        <option value="no" <?php echo e(old('extraction')=='no' ? 'selected' : ''); ?>>Sans extraction</option>
                                        <option value="yes" <?php echo e(old('extraction')=='yes' ? 'selected' : ''); ?>>Avec extraction</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Ajouter</button>
                        </form>
                    </div>
                    <!-- /.card-content -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>

<script>
    $(document).ready(function() {
        $('#description').summernote();
    });
  </script>
  <script>

        $("#cat_id").change(function(){


                var cat_id=$(this).val();


                if(cat_id != null){
                    //alert(cat_id);
                    $.ajax({
                        url:"/admin/localisation/"+cat_id+"/child",
                        type:"POST",
                        data:{
                            _token:"<?php echo e(csrf_token()); ?>",
                            cat_id:cat_id
                        },
                        success:function(response){
                            var html_option = "";
                            if(response.status){
                           //alert(cat_id);
                              $('#child_cat_div').removeClass('display-none');
                              $.each(response.data,function(id,title){
                                html_option += "<option value='"+id+"'>"+title+"</option>";
                              });
                            }else{
                                $('#child_cat_div').addClass('display-none');

                            }
                            $('#child_cat_id').html(html_option);

                        }
                    });
                }
        });
    if(child_cat_id != null){
        $('#cat_id').change();
    }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/product/create.blade.php ENDPATH**/ ?>