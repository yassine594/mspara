<?php $__env->startSection('content'); ?>
<!-- START SECTION BLOG -->
<section class="blog blog-section bg-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-12 blog-pots">
                <div class="row">
                    <div class="col-md-12 col-xs-12">
                        <div class="news-item details no-mb2">
                            <a class="news-img-link">
                                <div class="news-item-img">
                                    <img class="img-responsive" src="<?php echo e($blog->photo); ?>" alt="<?php echo e($blog->title); ?>">
                                </div>
                            </a>
                            <div class="news-item-text details pb-0">
                                <a><h3><?php echo e($blog->title); ?></h3></a>
                                <div class="dates">
                                    <span class="date"><?php
                                        $date = date('Y-m-d',strtotime($blog->updated_at));
                                        setlocale (LC_TIME, 'fr_FR.utf8','fra');
                                        echo (strftime("%A %d %B",strtotime($date)));
                                    ?> &nbsp;</span>

                                </div>
                                <div class="a2a_kit a2a_kit_size_32 a2a_default_style mt-3">
                                    <p>Partager sur: </p>
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_linkedin"></a>
                                    <a class="a2a_button_twitter"></a>
                                    </div>
                                    <script>
                                    var a2a_config = a2a_config || {};
                                    a2a_config.locale = "fr";
                                    a2a_config.num_services = 4;
                                    </script>
                                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <div class="news-item-descr big-news details visib mb-0" style="height: auto!important;">
                                    <p class="mb-3"><?php echo $blog->description; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <aside class="col-lg-3 col-md-12">
                <?php if(count(\App\Models\Blog::where('status','active')->where('id', '!=' ,$blog->id)->get())>0): ?>


                <div class="widget">
                    <div class="recent-post pt-5">
                        <h5 class="font-weight-bold mb-4">Dérniers actualités</h5>
                        <?php $__currentLoopData = \App\Models\Blog::where('status','active')->where('id', '!=' ,$blog->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="recent-main my-4">
                            <div class="row">
                                <div class="col-lg-6">
                            <div class="recent-img">
                                <a href="<?php echo e(route('blog.detail',$recent_blogs->slug)); ?>"><img style="object-fit: cover;width: 394px;height: 100px;" src="<?php echo e($recent_blogs->photo); ?>" alt="<?php echo e($recent_blogs->title); ?>"></a>
                            </div>
                                </div>
                                <div class="col-lg-6">
                            <div class="info-img">
                                <a href="<?php echo e(route('blog.detail',$recent_blogs->slug)); ?>"><h6 title="<?php echo e($recent_blogs->title); ?>"><?php echo e(substr($recent_blogs->title,0,30)); ?>...</h6>
                                </a>
                                <p><?php
                                    $date = date('Y-m-d',strtotime($recent_blogs->updated_at));
                                    setlocale (LC_TIME, 'fr_FR.utf8','fra');
                                    echo (strftime("%A %d %B",strtotime($date)));
                                ?> &nbsp;</p>
                            </div>
                        </div>
                        </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </aside>
        </div>
    </div>
</section>
<!-- END SECTION BLOG -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/pages/blog-details.blade.php ENDPATH**/ ?>