<div class="main-menu">
	<header class="header">
		<a href="<?php echo e(route('admin')); ?>" class="logo">Hengxin</a>
		<button type="button" class="button-close fa fa-times js__menu_close"></button>
	</header>
	<!-- /.header -->
	<div class="content">

		<div class="navigation">
			<ul class="menu js__accordion">
				<li class="current">
					<a class="waves-effect" href="<?php echo e(route('admin')); ?>"><i class="menu-icon mdi mdi-view-dashboard"></i><span>Tableau de bord</span></a>
				</li>
				<li>
					<a class="waves-effect parent-item" href="<?php echo e(route('banner.edit',1)); ?>"><i class="menu-icon mdi mdi-image"></i><span>Gestion de la bannière</span></a>

				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-sitemap"></i><span>Gestion des villes</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('localisation.index')); ?>">Villes/Débarquements</a></li>
						<li><a href="<?php echo e(route('localisation.create')); ?>">Ajouter Ville</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi fa fa-shopping-bag"></i><span>Gestion des Specialités</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('specialite.index')); ?>">specialités</a></li>
						<li><a href="<?php echo e(route('specialite.create')); ?>">Ajouter specialité</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-briefcase"></i><span>Gestion des locaux</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('local.index')); ?>">Locaux</a></li>
						<li><a href="<?php echo e(route('local.create')); ?>">Ajouter local</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-newspaper"></i><span>Gestion d'actualités</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('actualite.index')); ?>">Actualités</a></li>
						<li><a href="<?php echo e(route('actualite.create')); ?>">Ajouter actualité</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon fas fa-handshake"></i><span>Gestion d'équipe</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('equipe.index')); ?>">équipe</a></li>
						<li><a href="<?php echo e(route('equipe.create')); ?>">Ajouter Membre</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon fas fa-comment-dots"></i><span>Gestion des Témoignages</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('feedback.index')); ?>">Témoignages</a></li>
						<li><a href="<?php echo e(route('feedback.create')); ?>">Ajouter témoignage</a></li>
					</ul>
					<!-- /.sub-menu js__content -->
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon fa fa-users"></i><span>Gestion des admins</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo e(route('user.index')); ?>">Tous admins</a></li>
						<li><a href="<?php echo e(route('user.create')); ?>">Ajouter admin</a></li>
					</ul>
				</li>
                <li>
					<a class="waves-effect" href="<?php echo e(route('contacts.index')); ?>"><i class="menu-icon fa fa-envelope"></i><span>Messages</span></a>
                </li>
                <li>
					<a class="waves-effect" href="<?php echo e(route('devis.index')); ?>"><i class="menu-icon fas fa-globe-europe"></i><span>Devis</span></a>
                </li>
                <li>
					<a class="waves-effect" href="<?php echo e(route('newsletter.index')); ?>"><i class="menu-icon fas fa-clipboard-list"></i><span>NewsLetter</span></a>
                </li>
                <li>
					<a class="waves-effect" href="<?php echo e(route('languages.index')); ?>"><i class="menu-icon fas fa-clipboard-list"></i><span>Languages</span></a>
                </li>
                <li>
					<a class="waves-effect" href="<?php echo e(route('langs.index')); ?>"><i class="menu-icon fas fa-clipboard-list"></i><span>Languages list</span></a>
                </li>
               <!-- <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-tag"></i><span>Post tag</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="icons-font-awesome-icons.html">Font Awesome</a></li>
						<li><a href="icons-fontello.html">Fontello</a></li>
						<li><a href="icons-material-icons.html">Material Design Icons</a></li>
						<li><a href="icons-material-design-iconic.html">Material Design Iconic Font</a></li>
						<li><a href="icons-themify-icons.html">Themify Icons</a></li>
					</ul>
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-sitemap"></i><span>Post Category</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="icons-font-awesome-icons.html">Font Awesome</a></li>
						<li><a href="icons-fontello.html">Fontello</a></li>
						<li><a href="icons-material-icons.html">Material Design Icons</a></li>
						<li><a href="icons-material-design-iconic.html">Material Design Iconic Font</a></li>
						<li><a href="icons-themify-icons.html">Themify Icons</a></li>
					</ul>
				</li>

                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-star"></i><span>Review Management</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="icons-font-awesome-icons.html">Font Awesome</a></li>
						<li><a href="icons-fontello.html">Fontello</a></li>
						<li><a href="icons-material-icons.html">Material Design Icons</a></li>
						<li><a href="icons-material-design-iconic.html">Material Design Iconic Font</a></li>
						<li><a href="icons-themify-icons.html">Themify Icons</a></li>
					</ul>
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-gift"></i><span>Coupon Management</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="icons-font-awesome-icons.html">Font Awesome</a></li>
						<li><a href="icons-fontello.html">Fontello</a></li>
						<li><a href="icons-material-icons.html">Material Design Icons</a></li>
						<li><a href="icons-material-design-iconic.html">Material Design Iconic Font</a></li>
						<li><a href="icons-themify-icons.html">Themify Icons</a></li>
					</ul>
				</li>

				<li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon mdi mdi-comment"></i><span>Comments Management</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="icons-font-awesome-icons.html">Font Awesome</a></li>
						<li><a href="icons-fontello.html">Fontello</a></li>
						<li><a href="icons-material-icons.html">Material Design Icons</a></li>
						<li><a href="icons-material-design-iconic.html">Material Design Iconic Font</a></li>
						<li><a href="icons-themify-icons.html">Themify Icons</a></li>
					</ul>
				</li>-->
                <li>
					<a class="waves-effect" href="<?php echo e(route('about.index')); ?>"><i class="menu-icon mdi mdi-settings"></i><span>à propos</span></a>
                </li>
			</ul>
		</div>
	</div>
</div>

<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>