<?php $__env->startSection('content'); ?>


<div id="wrapper">
    <div class="main-content">
        <div class="row small-spacing">
            <div class="col-xs-9">
                <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="box-content card white">
                    <h4 class="box-title">à propos</h4>
                    <!-- /.box-title -->
                    <div class="col-md-12">
                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <form action="<?php echo e(route('about.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <fieldset style="border: solid 5px;padding: 10px;">
                                <legend style="width: max-content;padding: 3px;">Présentation de groupe</legend>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Titre</label>
                                <input type="text" class="form-control" placeholder="Titre" value="<?php echo e($about->heading); ?>" name="heading">
                            </div>
                            <div class="form-group">
                                <label>Video</label>
                                <input type="text" class="form-control" placeholder="Lien Youtube de video" value="<?php echo e($about->video); ?>" name="video">
                            </div>

                            <div class="m-t-20">
                                <label>Catalogue</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfm_cata" data-input="thumbnail_cata" data-preview="holder_cata" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnail_cata" class="form-control" type="text" name="catalogue" value="<?php echo e($about->catalogue); ?>">
                                  </div>
                                <div id="holder_cata" style="margin-top:15px;max-height:100px;">
                                    <a href="<?php echo e($about->catalogue); ?>" target="_blank" style="margin-top:15px;max-height:100px;font-size:25px;" ><i class="fa fa-file"></i></a>
                                </div>
                            </div>

                            <div class="m-t-20">
                                <label>Image</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnail" class="form-control" type="text" name="image" value="<?php echo e($about->image); ?>">
                                  </div>
                                <div id="holder" style="margin-top:15px;max-height:100px;">
                                    <img src="<?php echo e($about->image); ?>" style="margin-top:15px;max-height:100px;" />
                                </div>
                            </div>

                            <div class="m-t-20" style="margin-top: 25px;">
                                <label for="exampleInputEmail1">Présentation</label>

                                <textarea name="content" class="form-control" id="description" placeholder="Text...."><?php echo e($about->content); ?></textarea>
                            </div>
                            <div class="row">
                                 <div class="col-md-6">
                                    <div class="m-t-20" style="margin-top: 25px;">
                                        <label for="exampleInputEmail1">Solide expertise</label>

                                        <textarea name="solide_desc" class="form-control" placeholder="Text...."><?php echo e($about->solide_desc); ?></textarea>
                                    </div>
                                    <?php if(count($solides) != 0): ?>
                                    <table class="table table-striped table-bordered display" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Solide expertise</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $solides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($mission->title); ?></td>

                                                    <td>
                                                        <a href="<?php echo e(route('solide.edit',$mission->id)); ?>" class="float-left btn btn-danger btn-sm waves-effect waves-light" style="color:#fff;background-color:#000;">
                                                            <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                                        </a>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                    <h2 class="text-center">Il n'y a pas de solide expertise pour le moment!</h2>
                                    <?php endif; ?>
                                    <h4 class="box-title">
                                        <a class="btn btn-secondary" href="<?php echo e(route('solide.create')); ?>" ><i class="fa fa-plus-circle"></i> Ajouter solide expertise</a>
                                    </h4>

                                 </div>
                                 <div class="col-md-6">
                                    <div class="m-t-20" style="margin-top: 25px;">
                                        <label for="exampleInputEmail1">Mission</label>

                                        <textarea name="mission_desc" class="form-control" placeholder="Text...."><?php echo e($about->mission_desc); ?></textarea>
                                    </div>
                                    <?php if(count($missions) != 0): ?>
                                    <table class="table table-striped table-bordered display" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Mission</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($mission->title); ?></td>

                                                    <td>


                                                        <a href="<?php echo e(route('mission.edit',$mission->id)); ?>" class="float-left btn btn-danger btn-sm waves-effect waves-light" style="color:#fff;background-color:#000;">
                                                            <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                                        </a>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                    <h2 class="text-center">Il n'y a pas de missions pour le moment!</h2>
                                    <?php endif; ?>
                                    <h4 class="box-title">
                                        <a class="btn btn-secondary" href="<?php echo e(route('mission.create')); ?>" ><i class="fa fa-plus-circle"></i> Ajouter mission</a>
                                    </h4>
                                 </div>
                            </div>
                            </fieldset>
                            <br>

                            <fieldset style="border: solid 5px;padding: 10px;">
                                <legend style="width: max-content;padding: 3px;">Mot De Président</legend>

                                <div class="m-t-20" >
                                    <label for="exampleInputEmail1">Mot De Président</label>

                                    <textarea name="mot_president" class="form-control" id="mot_mot" placeholder="Text...."><?php echo e($about->mot_president); ?></textarea>
                                </div>
                                <div class="m-t-20" style="margin-top: 25px;">
                                    <label for="exampleInputEmail1">Description Mot De Président</label>

                                    <textarea name="desc_mot_president" class="form-control" id="description_mot" placeholder="Text...."><?php echo e($about->desc_mot_president); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nom & prènom</label>
                                    <input type="text" class="form-control" value="<?php echo e($about->nom_mot_president); ?>" name="nom_mot_president">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Poste</label>
                                    <input type="text" class="form-control" value="<?php echo e($about->poste_mot_president); ?>" name="poste_mot_president">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Lien video de mot de président</label>
                                    <input type="text" class="form-control" value="<?php echo e($about->video_mot_president); ?>" name="video_mot_president">
                                </div>
                                <div class="m-t-20" style="margin-bottom: 20px;">
                                    <label>Image Président</label>

                                    <div class="input-group">
                                        <span class="input-group-btn">
                                          <a id="lfm_mot" data-input="thumbnail_mot" data-preview="holder_mot" class="btn btn-primary">
                                            <i class="fa fa-picture-o"></i> Choose
                                          </a>
                                        </span>
                                        <input id="thumbnail_mot" class="form-control" type="text" name="photo_mot_president" value="<?php echo e($about->photo_mot_president); ?>">
                                      </div>
                                    <div id="holder_mot" style="margin-top:15px;max-height:100px;">
                                        <img src="<?php echo e($about->photo_mot_president); ?>" style="margin-top:15px;max-height:100px;" />
                                    </div>
                                </div>
                            </fieldset>
                            <br>

                            <fieldset style="border: solid 5px;padding: 10px;">
                                <legend style="width: max-content;padding: 3px;">Nos Contact</legend>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="text" class="form-control" placeholder="Email" value="<?php echo e($about->email); ?>" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="phone">Téléphone</label>
                                    <input type="text" class="form-control" placeholder="Téléphone" value="<?php echo e($about->phone); ?>" name="phone">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Adresse</label>
                                    <input type="text" class="form-control" placeholder="Adresse" value="<?php echo e($about->address); ?>" name="address">
                                </div>
                            </fieldset>
                            <br>

                            <fieldset style="border: solid 5px;padding: 10px;">
                                <legend style="width: max-content;padding: 3px;">Nos Social-Media</legend>
                                <div class="form-group">
                                    <label>Facebook</label>
                                    <input type="text" class="form-control" placeholder="https://facebook.com/Nomdevotrepagefb" value="<?php echo e($about->facebook); ?>" name="facebook">
                                </div>
                                <div class="form-group">
                                    <label>Instagram</label>
                                    <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepageinsta" value="<?php echo e($about->instagram); ?>" name="instagram">
                                </div>
                                <div class="form-group">
                                    <label>Twitter</label>
                                    <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepagetwitter" value="<?php echo e($about->twitter); ?>" name="twitter">
                                </div>
                                <div class="form-group">
                                    <label>Linkedin</label>
                                    <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepagelinkedin" value="<?php echo e($about->linkedin); ?>" name="linkedin">
                                </div>
                                <div class="form-group">
                                    <label>Youtube</label>
                                    <input type="text" class="form-control" placeholder="https://youtube.com/Nomdevotrechaineyoutube" value="<?php echo e($about->youtube); ?>" name="youtube">
                                </div>
                            </fieldset>

                            <br>
                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Enregistrer</button>
                        </form>
                    </div>
                    <!-- /.card-content -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
<script>
    $('#lfm_mot').filemanager('image');
</script>
<script>
    $('#lfm_cata').filemanager('file');
</script>
<script>
    $(document).ready(function() {
        $('#description').summernote();
    });
  </script>
<script>
    $(document).ready(function() {
        $('#description_mot').summernote();
    });
  </script>
  <script>
    $(document).ready(function() {
        $('#mot_mot').summernote();
    });
  </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/about/index.blade.php ENDPATH**/ ?>