<?php $__env->startSection('content'); ?>
    <!-- START SECTION PROPERTIES LISTING -->
    <section class="single-proper blog details" style="padding-top:130px!important;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12 blog-pots">
                    <div class="row">
                        <div class="col-md-12">
                            <section class="headings-2 pt-0">
                                <div class="pro-wrapper">
                                    <div class="detail-wrapper-body">
                                        <div class="listing-title-bar">
                                            <h3><?php echo e($product->title); ?> <span class="mrg-l-5 category-tag"><?php if($product->conditions == 'rent'): ?>
                                                à louer
                                                <?php else: ?>
                                                à vendre
                                            <?php endif; ?></span></h3>
                                            <div class="mt-0">
                                                <a href="#listing-location" class="listing-address">
                                                    <i class="fa fa-map-marker pr-2 ti-location-pin mrg-r-5"></i><?php echo e(\App\Models\Category::where('id',$product->cat_id)->value('title')); ?>

                                                    <?php if($product->child_cat_id != NULL): ?>
                                                        , <?php echo e(\App\Models\Category::where('id',$product->child_cat_id)->value('title')); ?>

                                                    <?php endif; ?>,<?php echo e($product->address); ?>

                                                </a>
                                            </div>


                                        </div>
                                            <div class="a2a_kit a2a_kit_size_32 a2a_default_style mt-3">
                                            <p>Partager sur: </p>
                                            <a class="a2a_button_facebook"></a>
                                            <a class="a2a_button_linkedin"></a>
                                            <a class="a2a_button_twitter"></a>
                                            </div>
                                            <script>
                                            var a2a_config = a2a_config || {};
                                            a2a_config.locale = "fr";
                                            a2a_config.num_services = 4;
                                            </script>
                                            <script async src="https://static.addtoany.com/menu/page.js"></script>
                                    </div>
                                    <div class="single detail-wrapper mr-2">
                                        <div class="detail-wrapper-body">
                                            <div class="listing-title-bar">
                                                <h4><?php if($product->conditions == 'rent'): ?>
                                                    €<?php echo e(number_format($product->price)); ?>/mois
                                                    <?php else: ?>
                                                    €<?php echo e(number_format($product->price)); ?>

                                                <?php endif; ?></h4>
                                                <div class="mt-0">
                                                    <a href="#listing-location" class="listing-address">
                                                        <p><?php echo e($product->surface); ?> m²</p>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product_data">
                                            <!-- input_cart -->
                                            <input type="hidden" class="product_id" value="<?php echo e($product->id); ?>">

                                            <button type="button" class="add-to-cart-btn btn btn-warning" style="color: white;">Ajouter à ma sélection</button>

                                        </div>
                                    </div>
                                </div>

                            </section>
                            <!-- main slider carousel items -->
                            <div id="listingDetailsSlider" class="carousel listing-details-sliders slide mb-30">
                                <h5 class="mb-4">Galerie</h5>
                                <div class="carousel-inner">
                                    <?php
                                        $photos = explode(",",$product->photo);
                                        $i = 0;

                                    ?>

                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="<?php if($i == 0): ?>
                                    active
                                    <?php endif; ?> item carousel-item" data-slide-number="<?php echo e($i); ?>">
                                        <img src="<?php echo e($photo); ?>" class="img-fluid" alt="slider-listing" style="width: 100%;">
                                    </div>
                                    <?php
                                        $i++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <a class="carousel-control left" href="#listingDetailsSlider" data-slide="prev"><i class="fa fa-angle-left" style="color: #fff"></i></a>
                                    <a class="carousel-control right" href="#listingDetailsSlider" data-slide="next"><i class="fa fa-angle-right" style="color: #fff"></i></a>

                                </div>
                                <!-- main slider carousel nav controls -->
                                <ul class="carousel-indicators smail-listing list-inline">
                                    <?php
                                        $photos = explode(",",$product->photo);
                                        $i = 0;

                                    ?>

                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-inline-item <?php if($i == 0): ?>
                                    active
                                    <?php endif; ?>">
                                        <a id="carousel-selector-<?php echo e($i); ?>" class="selected" data-slide-to="<?php echo e($i); ?>" data-target="#listingDetailsSlider">
                                            <img src="<?php echo e($photo); ?>" class="img-fluid" alt="listing-small">
                                        </a>
                                    </li>
                                    <?php
                                    $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                                <!-- main slider carousel items -->
                            </div>
                            <div class="blog-info details mb-30">
                                <h5 class="mb-4">Description</h5>
                                <p class="mb-3"><?php echo $product->description; ?></p>

                            </div>
                        </div>
                    </div>
                    <div class="single homes-content details mb-30">
                        <!-- title -->
                        <h5 class="mb-4">Details de local</h5>
                        <ul class="homes-list clearfix">
                            <li>
                                <span class="font-weight-bold mr-1">Property ID:</span>
                                <span class="det">V254680</span>
                            </li>
                            <li>
                                <span class="font-weight-bold mr-1">Status:</span>
                                <span class="det"><?php if($product->conditions == 'rent'): ?>
                                    à louer
                                    <?php else: ?>
                                    à vendre
                                <?php endif; ?></span>
                            </li>
                            <li>
                                <span class="font-weight-bold mr-1">Surface:</span>
                                <span class="det"><?php echo e($product->surface); ?> m²</span>
                            </li>
                                <?php if($product->facade != NULL): ?>
                                <li>
                                    <span class="font-weight-bold mr-1">Façade:</span>
                                    <span class="det"><?php echo e($product->facade); ?> m</span>
                                </li>
                                <?php endif; ?>
                                <?php if($product->rdc != NULL): ?>
                            <li>
                                <span class="font-weight-bold mr-1">Rez de chaussée:</span>
                                <span class="det"><?php echo e($product->rdc); ?> m²</span>
                            </li>
                            <?php endif; ?>
                            <?php if($product->petage != NULL): ?>
                            <li>
                                <span class="font-weight-bold mr-1">Premiére étage:</span>
                                <span class="det"><?php echo e($product->petage); ?> m²</span>
                            </li>
                            <?php endif; ?>
                            <li>
                                <span class="font-weight-bold mr-1">Ville:</span>
                                <span class="det"><?php echo e(\App\Models\Category::where('id',$product->cat_id)->value('title')); ?></span>
                            </li>
                            <?php if(\App\Models\Category::where('id',$product->cat_child_id)->value('title') != NULL): ?>
                            <li>
                                <span class="font-weight-bold mr-1">Débarquement:</span>
                                <span class="det"><?php echo e(\App\Models\Category::where('id',$product->cat_child_id)->value('title')); ?></span>
                            </li>
                            <?php endif; ?>
                            <li>
                                <span class="font-weight-bold mr-1">Specialité:</span>
                                <span class="det"><?php echo e(\App\Models\Brand::where('id',$product->brand_id)->value('title')); ?></span>
                            </li>
                            <li>
                                <span class="font-weight-bold mr-1">Disponibilité:</span>
                                <span class="det"><?php echo e($product->date_d); ?></span>
                            </li>
                        </ul>
                        <!-- title -->
                        <h5 class="mt-5">Conditions</h5>
                        <!-- cars List -->
                        <ul class="homes-list clearfix">
                            <li>
                                <i class="fa fa-check-square" aria-hidden="true"></i>
                                <span><?php if($product->fond == "fdc"): ?>
                                    Fond de commerce
                                <?php elseif($product->fond == "dab"): ?>
                                    Droit au bail
                                <?php elseif($product->fond == "mc"): ?>

                                    Murs commerciaux

                                <?php elseif($product->fond == "lp"): ?>
                                    Location pure
                                    <?php endif; ?>

                                </span>
                            </li>
                            <?php if($product->extraction == "yes"): ?>
                            <li>
                                <i class="fa fa-check-square" aria-hidden="true"></i>
                                <span>
                                    Licence numéro 4
                                </span>
                            </li>
                            <?php endif; ?>

                        </ul>
                    </div>

<?php if(!empty($product->video)): ?>

                    <div class="property wprt-image-video w50 pro" style="position: relative;">
                        <h5>Video de local</h5>
                        <img alt="image" src="<?php echo e($photos[0]); ?>">
                        <a class="icon-wrap popup-video popup-youtube" href="<?php echo e($product->video); ?>">
                            <i class="fa fa-play"></i>
                        </a>
                        <div class="iq-waves">
                            <div class="waves wave-1"></div>
                            <div class="waves wave-2"></div>
                            <div class="waves wave-3"></div>
                        </div>
                    </div>

<?php endif; ?>
                </div>
                <aside class="col-lg-4 col-md-12 car">
                    <div class="single widget">
                        <!-- Start: Schedule a Tour -->

                        <div class="schedule widget-boxed mt-33 mt-0">
                            <div>
                                <h4><i class="fa fa-calendar pr-3 padd-r-10"></i>Demande d'informations</h4>
                            </div>
                            <div class="widget-boxed-body">
                                <div class="agent-contact-form-sidebar">
                                    <form name="contact_form" method="post" action="<?php echo e(route('devis.submit')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="nom_local" value="<?php echo e($product->title); ?>" >
                                        <input type="text" id="fname" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nom et Prénom" required />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <input type="number" id="pnumber" value="<?php echo e(old('phone')); ?>" name="phone" placeholder="Numéro de téléphone" required />
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <input type="email" id="emailid" name="email" placeholder="Adresse Email" value="<?php echo e(old('email')); ?>" required />
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <textarea placeholder="Message" name="content" required><?php echo e(old('content')); ?></textarea>
                                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <p> Fixez un Rendez-vous:</p>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12 book">
                                                <input type="text" id="reservation-date" data-lang="fr" data-large-mode="true" data-dd-opt-format="y-mm-dd" data-min-year="2017" data-max-year="2040" data-id="datedropper-0" data-theme="my-style" class="form-control" name="date_d" value="<?php echo e(old('date_d')); ?>" readonly="">
                                            </div>
                                            <?php $__errorArgs = ['date_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="col-lg-6 col-md-12 book2">
                                                <input type="text" id="reservation-time" name="time_d" value="<?php echo e(old('time_d')); ?>" class="form-control" readonly="">
                                            </div>
                                            <?php $__errorArgs = ['time_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <button type="submit" id="submit-contact" class="btn reservation btn-radius theme-btn full-width mrg-top-10">Envoyez</button>
                                    </form>
                                </div>

                            </div>
                        </div>


                        <!-- End: Schedule a Tour -->
                        <!-- end author-verified-badge -->
                        <div class="sidebar">
                            <div class="main-search-field-2">
                                <div class="widget-boxed mt-5">
                                    <div class="widget-boxed-header mb-5">
                                        <h4>Recommandations</h4>
                                    </div>
                                    <div class="widget-boxed-body">
                                        <div class="slick-lancers">

                                        <?php $__currentLoopData = $randomproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $photos = explode(",",$rand->photo);
                                        ?>
                                            <div class="agents-grid mr-0">
                                                <div class="listing-item compact">
                                                    <a href="<?php echo e(route('product.detail',$rand->slug)); ?>" class="listing-img-container">
                                                        <div class="listing-badges">
                                                            <span class="featured"><?php if($rand->conditions == 'rent'): ?>
                                                                €<?php echo e(number_format($rand->price)); ?>/mois
                                                                <?php else: ?>
                                                                €<?php echo e(number_format($rand->price)); ?>

                                                            <?php endif; ?></span>
                                                            <span><?php if($rand->conditions == 'rent'): ?>
                                                                à louer
                                                                <?php else: ?>
                                                                à vendre
                                                            <?php endif; ?></span>
                                                        </div>
                                                        <div class="listing-img-content">
                                                            <span class="listing-compact-title"><?php echo e($rand->title); ?> <i><?php echo e(\App\Models\category::where('id',$rand->cat_id)->value('title')); ?></i></span>

                                                        </div>
                                                        <img src="<?php echo e($photos[0]); ?>" alt="<?php echo e($rand->title); ?>">
                                                    </a>
                                                </div>
                                            </div>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-boxed mt-5">
                                    <div class="widget-boxed-header">
                                        <h4>Dérnieres Annonces</h4>
                                    </div>
                                    <div class="widget-boxed-body">
                                        <div class="recent-post">
                                            <?php $__currentLoopData = $recentproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $photos = explode(",",$recent->photo);
                                            ?>
                                            <div class="recent-main mb-2">
                                                <div class="row">
                                                    <div class="col-lg-5">
                                                <div class="recent-img">
                                                    <a href="<?php echo e(route('product.detail',$recent->slug)); ?>"><img style="object-fit: cover;width: 354px;height: 100px;" src="<?php echo e($photos[0]); ?>" alt="<?php echo e($recent->title); ?>"></a>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="info-img">
                                                    <a href="<?php echo e(route('product.detail',$recent->slug)); ?>">
                                                        <h6 title="<?php echo e($recent->title); ?>"><?php echo e(substr($recent->title,0,50)); ?>...</h6></a>
                                                    <p><?php if($recent->conditions == 'rent'): ?>
                                                        €<?php echo e(number_format($recent->price)); ?>/mois
                                                        <?php else: ?>
                                                        €<?php echo e(number_format($recent->price)); ?>

                                                    <?php endif; ?></p>
                                                </div>
                                            </div>
                                            </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </div>
                                    </div>
                                </div>
                                <!-- Start: Specials offer -->
                                <div class="widget-boxed popular mt-5">
                                    <div class="widget-boxed-header">
                                        <h4>Promo</h4>
                                    </div>
                                    <div class="widget-boxed-body">
                                        <div class="banner"><img src="<?php echo e(asset('frontend/images/single-property/banner.jpg')); ?>" alt=""></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
            <!-- START SIMILAR PROPERTIES -->
            <section class="similar-property featured portfolio p-0 bg-white-inner">
                <div class="container">
                    <h5>Locaux similaires</h5>
                    <div class="row portfolio-items">


                            <?php $__currentLoopData = $product->rel_prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $photos = explode(",",$related->photo);
                    ?>
<div class="item col-lg-4 col-md-6 col-xs-12 landscapes">
                <div class="agents-grid" data-aos="fade-up" >
                    <div class="landscapes">
                        <div class="project-single">
                            <div class="project-inner project-head">
                                <div class="project-bottom">
                                    <h4><a href="<?php echo e(route('product.detail',$related->slug)); ?>">Voir local</a><span class="category"><?php echo e($related->title); ?></span></h4>
                                </div>
                                <div class="homes">
                                    <!-- homes img -->
                                    <a href="<?php echo e(route('product.detail',$related->slug)); ?>" class="homes-img">
                                        <?php if($related->fond=='yes'): ?>
                                        <div class="homes-tag button alt featured" title="Fond de commerce" >FDC</div>
                                        <?php endif; ?>

                                        <div class="homes-tag button alt sale">à vendre</div>
                                        <div class="homes-price"><?php echo e(\App\Models\Brand::where('id',$related->brand_id)->value('title')); ?></div>
                                        <img src="<?php echo e($photos[0]); ?>" alt="home-1" class="img-responsive" style="height: 250px;object-fit: cover;">
                                    </a>
                                </div>
                                <div class="button-effect">
                                    <a href="<?php echo e(route('product.detail',$related->slug)); ?>" class="btn"><i class="fa fa-link"></i></a>
                                    <?php if(!empty($related->video)): ?>

                                    <a href="<?php echo e($related->video); ?>" class="btn popup-video popup-youtube"><i class="fas fa-video"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- homes content -->
                            <div class="homes-content">
                                <!-- homes address -->
                                <h3><a href="<?php echo e(route('product.detail',$related->slug)); ?>"><?php echo e($related->title); ?></a></h3>
                                <p class="homes-address mb-3">
                                    <a href="<?php echo e(route('product.detail',$related->slug)); ?>">
                                        <i class="fa fa-map-marker"></i><span><?php echo e($related->address); ?></span>
                                    </a>
                                </p>
                                <!-- homes List -->
                                <ul class="homes-list clearfix">
                                    <li>
                                        <i class="fas fa-arrows-alt-h" aria-hidden="true"></i>
                                        <span>surface: <?php echo e($related->surface); ?> m²</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-building" aria-hidden="true"></i>
                                        <span>façade: <?php echo e($related->facade); ?> m</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-object-group" aria-hidden="true"></i>
                                        <span>RDC: <?php echo e($related->rdc); ?> m²</span>
                                    </li>
                                    <li>
                                        <i class="fas fa-warehouse" aria-hidden="true"></i>
                                        <span>1<sup>er</sup>: <?php echo e($related->petage); ?> m²</span>
                                    </li>
                                </ul>
                                <!-- Price -->
                                <div class="price-properties">
                                    <h3 class="title mt-3">
                                        <a href="<?php echo e(route('product.detail',$related->slug)); ?>">€<?php echo e(number_format($related->price)); ?></a>
                                    </h3>
                                </div>
                                <div class="footer">
                                    <a>
                                        <i class="fa fa-map-marker"></i> <?php echo e(\App\Models\Category::where('id',$related->cat_id)->value('title')); ?>

                                        <?php if($related->child_cat_id != NULL): ?>
                                            , <?php echo e(\App\Models\Category::where('id',$related->child_cat_id)->value('title')); ?>

                                        <?php endif; ?>
                                    </a>
                                    <br>
                                    <br>
                                    <span style="float: none">
                                        <i class="fa fa-calendar"></i> Disponibilité : <?php echo e($related->date_d); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </section>
            <!-- END SIMILAR PROPERTIES -->
        </div>
    </section>
    <!-- END SECTION PROPERTIES LISTING -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('upscripts'); ?>
<script src="<?php echo e(asset('frontend/js/search.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/slick4.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php if(session()->has('success')): ?>

<script>
 $(document).ready(function () {
alertify.set('notifier','position','bottom-left');
alertify.success('<?php echo e(session()->get('success')); ?>');
 });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/pages/product/product-detail.blade.php ENDPATH**/ ?>