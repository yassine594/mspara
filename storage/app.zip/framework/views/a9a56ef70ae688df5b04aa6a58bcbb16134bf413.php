<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 news-block">
    <div class="inner-box">
        <div class="image">
            <img src="<?php echo e($item->photo); ?>" style="height: 270px;object-fit: cover;" alt="">
            <div class="overlay-two" style="background: rgb(27 27 27 / 0.9);">
                <a href="<?php echo e(route('blog.detail',$item->slug)); ?>"><span class="fa fa-chevron-right"></span></a>
            </div>
        </div>
        <div class="lower-content">
            <div class="category">[<i class="fas fa-folder"></i>
            <?php if($item->type_blog == "event"): ?>
                Evenements
            <?php else: ?>
                News
            <?php endif; ?>
             ]</div>
            <h3><a href="<?php echo e(route('blog.detail',$item->slug)); ?>"><?php echo e($item->title); ?></a></h3>
            <ul class="post-meta">
                <li><a><i class="far fa-clock"></i>
                <?php
                    $date = date('Y-m-d',strtotime($item->updated_at));
                    setlocale (LC_TIME, 'fr_FR.utf8','fra');
                    echo (strftime("%A %d %B %Y",strtotime($date)));
                ?>
                </a></li>
            </ul>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/layouts/_single-blog.blade.php ENDPATH**/ ?>