<?php $__env->startSection('content'); ?>

<style>
    @media  only screen and (max-width: 600px) {
  .hedi-menu {
    height: 180px !important;
  }
}
</style>
<!-- Page Title -->
<section class="page-title hedi-menu" style="background:black;height: 128px;">
    <div class="auto-container">
        <div class="content-box" style="padding: 63px 0px;">
            <div class="content-wrapper">

            </div>
        </div>
    </div>
</section>

<!-- Service details -->
<div class="service-details-page">
    <div class="auto-container">
        <div class="row">
            <div class="col-lg-8">
                <div class="service-details">
                    <div class="image"><img src="<?php echo e($blog->photo); ?>" alt=""></div>
                    <div class="text-block">
                        <h2><?php echo e($blog->title); ?></h2>
                        <div class="text">
                            <p><?php echo $blog->description; ?></p>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-lg-4">

                    <?php if($blog->doc != null): ?>
                    <div class="link-btn mb-3">
                        <a href="<?php echo e($blog->doc); ?>" style="border: solid #ee3032 1px;" class="theme-btn style-seven btn-block " download><i class="flaticon-download-1"></i><span> Télécharger Catalogue</span></a>
                    </div>
                    <?php endif; ?>


                <aside class="service-sidebar">
                    <div class="widget category-widget">
                        <ul>
                            <?php $__currentLoopData = $related_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li
                            <?php if($all->id == $blog->id): ?>
                            class="active"
                            <?php endif; ?>

                            >
                            <a href="<?php echo e(route('service.detail',$all->slug)); ?>">
                                <?php echo e($all->title); ?>

                            </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>


                </aside>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/pages/service-details.blade.php ENDPATH**/ ?>