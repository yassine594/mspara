<?php $__env->startSection('content'); ?>


<div class="main-content">
<div class="col-lg-12">
    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<h4 class="box-title"><a class="btn btn-secondary" href="<?php echo e(route('feedback.create')); ?>" ><i class="fa fa-plus-circle"></i> Ajouter Socièté</a></h4>
    <table class="table table-striped table-bordered display" style="width:100%">
        <thead>
            <tr>
                <th>S.N</th>
                <th>Nom de socièté</th>
                <th>Photo</th>
                <th>Description</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>S.N</th>
                <th>Nom de socièté</th>
                <th>Photo</th>
                <th>Description</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <?php if($item->photo != NULL): ?>
                        <img src="<?php echo e($item->photo); ?>" alt="<?php echo e($item->title); ?>" style="width:100px;" />
                        <?php else: ?>
                        <img src="https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg" alt="<?php echo e($item->title); ?>" style="width:100px;" />
                        <?php endif; ?>
                    </td>
                    <td><?php echo $item->description; ?></td>

                    <td>
                        <div class="switch success">

                           <input name="toogle" value="<?php echo e($item->id); ?>" type="checkbox" <?php echo e($item->status=='active' ? 'checked': ''); ?> id="switch-<?php echo e($item->id); ?>">
                            <label for="switch-<?php echo e($item->id); ?>">active</label>
                        </div>
                    </td>
                    <td>

                    <form action="<?php echo e(route('feedback.destroy',$item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="button" data-id="<?php echo e($item->id); ?>" class="float-left dltBtn btn btn-danger btn-sm waves-effect waves-light" style="color:#fff;background-color:#000;"><i class="fa fa-trash" aria-hidden="true"></i></button>
                    </form>

                        <a class="float-left" href="<?php echo e(route('feedback.edit',$item->id)); ?>"><i class="btn btn-warning btn-sm waves-effect waves-light fas fa-pencil-alt" aria-hidden="true"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.dltBtn').click(function(e){
            var form=$(this).closest('form');
            var dataID=$(this).data('id');
            e.preventDefault();

            swal({
                title: "Êtes-vous sûr?",
                text: "Une fois supprimé, vous ne pourrez pas récupérer ce Témoignage!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    form.submit();
                    swal("Poof! Votre Socièté a été supprimée!", {
                    icon: "success",
                    });
                } else {
                    swal("Votre Socièté non supprimée!");
                }
                });
        });
</script>

    <script>
        $('input[name=toogle]').change(function(){
            var mode = $(this).prop('checked');
            var id = $(this).val();
            //alert(id);
            $.ajax({
                url:"<?php echo e(route('feedback.status')); ?>",
                type:"POST",
                data:{
                    _token:'<?php echo e(csrf_token()); ?>',
                    mode:mode,
                    id:id,
                },
                success:function(response){
                    if(response.status){
                        alert(response.msg);
                    }
                    else{
                        alert('Please try again!');
                    }
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/feedback/index.blade.php ENDPATH**/ ?>