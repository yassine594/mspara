<?php $__env->startSection('content'); ?>

<style>
    @media  only screen and (max-width: 600px) {
  .hedi-menu {
    height: 180px !important;
  }
}
</style>
<!-- Page Title -->
<section class="page-title hedi-menu" style="background:black;height: 128px;">
    <div class="auto-container">
        <div class="content-box" style="padding: 63px 0px;">
            <div class="content-wrapper">

            </div>
        </div>
    </div>
</section>

<!-- Contact Form section -->
<section class="contact-form-section style-four">
    <div class="auto-container">
        <div class="row">
            <div class="col-lg-12">
                <div class="office-address">
                    <div class="icon-box">
                        <div class="icon"><i class="flaticon-geolocation"></i></div>
                        <h4>Visitez notre usine</h4>
                        <div class="text"><?php echo e(get_setting('address')); ?></div>
                    </div>
                    <div class="text">
                        Nous sommes impatients de développer de nouvelles opportunités et de produire des produits de classe mondiale pour nos clients.
                        Contactez notre équipe pour en discuter.
                    </div>
                </div>
                <div class="contact-info mb-30">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="icon-box">
                                <div class="icon"><i class="flaticon-call"></i></div>
                                <h4>Téléphone</h4>
                                <div class="text"><a href="tel:<?php echo e(get_setting('phone')); ?>"><?php echo e(get_setting('phone')); ?></a></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="icon-box">
                                <div class="icon"><i class="flaticon-correspondence"></i></div>
                                <h4>Email</h4>
                                <div class="text"><a href="mailto:<?php echo e(get_setting('email')); ?>"><?php echo e(get_setting('email')); ?></a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wrapper-box">
                    <div class="sec-title">
                        <div class="sub-title">Envoyer Un Message</div>
                        <h2>Besoin D'aide? Envoyer Un Message</h2>
                    </div>
                    <!--Contact Form-->
                    <div class="contact-form">
                        <form name="contactform" method="post" action="<?php echo e(route('contact.submit')); ?>" id="contact-form">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal4bbc73356588fb92e23dd2eee41cd748d85698a7 = $component; } ?>
<?php $component = $__env->getContainer()->make(Lukeraymonddowning\Honey\Views\Honey::class, []); ?>
<?php $component->withName('honey'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4bbc73356588fb92e23dd2eee41cd748d85698a7)): ?>
<?php $component = $__componentOriginal4bbc73356588fb92e23dd2eee41cd748d85698a7; ?>
<?php unset($__componentOriginal4bbc73356588fb92e23dd2eee41cd748d85698a7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Nom</label>
                                        <input id="name" type="text" name="name" placeholder="Nom" value="<?php echo e(old('name')); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Prénom</label>
                                        <input id="name" type="text" name="lastname" placeholder="Prénom" value="<?php echo e(old('lastname')); ?>" required>
                                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input id="email" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">Numéro de télephone</label>
                                        <input id="phone" type="text" name="phone" placeholder="Numéro de télephone" value="<?php echo e(old('phone')); ?>" required>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">Sujet de message</label>
                                        <input id="phone" type="text" name="subject" placeholder="Sujet de message" value="<?php echo e(old('subject')); ?>" required>
                                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="message">Message</label>
                                        <textarea id="message" name="content" required rows="8" placeholder="Message"><?php echo e(old('content')); ?></textarea>
                                        <div class="form-btn">

                                            <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">

                                            <button class="theme-btn btn-style-one" type="submit" data-loading-text="Please wait..."><span><i class="flaticon-up-arrow"></i>Envoyer</span></button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--End Contact Form-->
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Map Section -->
<section class="map-section">
    <div class="contact-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2721.517046329986!2d10.66018012101702!3d35.78894747526715!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x13027580d686bd19%3A0xd06c2769ee271609!2sHPC%20GROUP!5e0!3m2!1sfr!2stn!4v1644838599928!5m2!1sfr!2stn" width="600" height="550" frameborder="0" style="border:0; width: 100%" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>


    </div>
</section>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if(session()->has('success')): ?>

<script>
 $(document).ready(function () {
alertify.set('notifier','position','bottom-left');
alertify.success('<?php echo e(session()->get('success')); ?>');
 });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/pages/contact-us.blade.php ENDPATH**/ ?>