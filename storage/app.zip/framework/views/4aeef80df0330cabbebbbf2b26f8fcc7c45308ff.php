
<div class="fixed-navbar">
	<div class="pull-left">
		<button type="button" class="menu-mobile-button glyphicon glyphicon-menu-hamburger js__menu_mobile"></button>
		<!-- /.page-title -->
	</div>
	<!-- /.pull-left -->
	<div class="pull-right">
		<!-- /.ico-item -->
		<div class="ico-item fa fa-arrows-alt js__full_screen"></div>
		<!-- /.ico-item fa fa-fa-arrows-alt -->


		<div class="ico-item">
			<img src="https://icon-library.com/images/my-account-icon/my-account-icon-13.jpg" alt="" class="ico-img">
			<ul class="sub-ico-item">
				<li>
                    <a class="dropdown-item js__logout" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                     Déconnexion
                 </a>

                 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                     <?php echo csrf_field(); ?>
                 </form>
                </li>
			</ul>
			<!-- /.sub-ico-item -->
		</div>
		<!-- /.ico-item -->
	</div>
	<!-- /.pull-right -->
</div>
<?php /**PATH C:\xampp\htdocs\hpc\resources\views/backend/layouts/nav.blade.php ENDPATH**/ ?>