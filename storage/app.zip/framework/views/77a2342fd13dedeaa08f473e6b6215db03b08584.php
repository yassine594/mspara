

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(\App\Models\Category::where(['id' => $item->cat_id])->value('status') == 'active'): ?>
<?php if(\App\Models\Brand::where(['id' => $item->brand_id])->value('status') == 'active'): ?>


<?php
    $photos = explode(",",$item->photo);
?>
<div class="item col-lg-6 col-md-6 col-xs-12 landscapes sale">
    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="recent-16 aos-init aos-animate" data-aos="fade-up">
        <?php if($item->fond=='fdc'): ?>
                                        <div style="line-height: 1.5;font-size: 13px;font-weight: 600;padding: 6px 14px;border-radius: 2px;color: #fff;border: none;display: inline-block;z-index: 1;text-align: center;" class="homes-tag button alt featured" title="Fond de commerce" >FDC</div>
        <?php endif; ?>
        <?php if($item->conditions=='sale'): ?>
        <div style="line-height: 1.5;font-size: 13px;font-weight: 600;padding: 6px 14px;border-radius: 2px;color: #fff;border: none;display: inline-block;z-index: 1;text-align: center;" class="homes-tag button alt sale">à vendre</div>
            <?php elseif($item->conditions=='rent'): ?>
            <div style="line-height: 1.5;font-size: 13px;font-weight: 600;padding: 6px 14px;border-radius: 2px;color: #fff;border: none;display: inline-block;z-index: 1;text-align: center;" class="homes-tag button sale rent">à louer</div>
        <?php endif; ?>
        <div class="recent-img16 img-center" style="background-image: url('<?php echo e($photos[0]); ?>');height: 450px;object-fit: cover;"></div>
        <div class="recent-content"></div>
        <div class="recent-details">
            <div class="recent-title"><?php echo e($item->title); ?></div>
            <?php if($item->conditions == 'rent'): ?>
            <div class="recent-price">€<?php echo e(number_format($item->price)); ?>/mois</div>
            <?php elseif($item->conditions == 'sale'): ?>
            <div class="recent-price">€<?php echo e(number_format($item->price)); ?></div>
            <?php endif; ?>

            <div class="house-details">Surface: <?php echo e($item->surface); ?> m² <span>|</span> Façade: <?php echo e($item->facade); ?> m </div>
            <div class="house-details">RDC: <?php echo e($item->rdc); ?> m² <span>|</span> 1<sup>er</sup> étage: <?php echo e($item->petage); ?> m²</div>
        </div>
        <div class="view-proper">Voir Détails</div>
    </a>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/layouts/_single-product.blade.php ENDPATH**/ ?>