<?php $__env->startSection('content'); ?>
<style>
 @media  only screen and (max-width: 600px) {
  .hedi-menu {
    height: 180px !important;
  }
}
</style>
<!-- Page Title -->
<section class="page-title hedi-menu" style="background:black;height: 128px;">
    <div class="auto-container">
        <div class="content-box" style="padding: 63px 0px;">
            <div class="content-wrapper">

            </div>
        </div>
    </div>
</section>

<!-- shop-details -->
<section class="shop-details" style="padding: 120px 0px 0px 0px;">
    <div class="auto-container">
        <div class="product-details-content">
            <div class="row clearfix">

                <div class="col-lg-12 content-column">

                    <div class="product-details">
                        <?php if($categories->photo !== ""): ?>
                        <div >

                                            <div class="image" style="text-align: center"><img style="width: 80%;" src="<?php echo e($categories->photo); ?>" alt=""></div>


                        </div>
                        <?php endif; ?>


                        <div class="title-box">
                            <h3><?php echo e($categories->title); ?></h3>
                        </div>
                        <?php if($categories->description): ?>
                        <div class="text">
                            <p><?php echo $categories->description; ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- shop-details end -->
<?php if(count($gammes) !== 0): ?>



    <section class="projects-section-two" style="background:none;padding-top:0;">
        <div class="auto-container">

            <!--Filter-->
            <div class="filters">
                <ul class="filter-tabs filter-btns">
                    <?php
                        $i = 0 ;
                    ?>
                    <?php $__currentLoopData = $gammes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gamme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="filter <?php if($i==0): ?> active <?php endif; ?>" data-role="button" data-filter=".gamme-<?php echo e($gamme->id); ?>"><?php echo e($gamme->title); ?></li>
                        <?php
                        if($i == 0){
                            $first_gamme = $gamme->id;
                        }
                        $i++ ;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!--Sortable Galery-->
            <div class="sortable-masonry">

                <div class="items-container row" style="position: relative; height: max-content;">
                    <?php if(count( \App\Models\SousGamme::where('child_cat_id',$categories->id)->get()) == 0 ): ?>

                        <?php
                        $i = 0 ;
                        ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $photos = explode(",",$item->photo);
                            ?>
                                <div class="col-lg-3 col-md-6 project-block masonry-item <?php if($item->gamme_id== $first_gamme): ?> all <?php endif; ?> gamme-<?php echo e($item->gamme_id); ?>" >
                                    <div class="inner-box">
                                        <div class="image">
                                            <img src="<?php echo e($item->photo); ?>" style="height: 250px;object-fit: contain;" alt="">
                                        </div>
                                        <div class="overlay-content">
                                            <div>
                                                <h4><?php echo e($item->title); ?></h4>
                                            </div>
                                            <div class="link-btn"><a href="<?php echo e(route('product.detail',$item->slug)); ?>"><span class="flaticon-arrow-1"></span></a></div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            $i++ ;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php else: ?>

                        <?php
                        $k = 0 ;
                        $i = 0 ;
                        ?>
                        <?php $__currentLoopData = $gammes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gamme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-12 col-md-12 project-block masonry-item <?php if($i == 0): ?> all <?php endif; ?> gamme-<?php echo e($gamme->id); ?>" >
                        <!-- faq section -->
                        <section class="faq-section style-two" style="padding-top: 0">
                            <div class="auto-container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <ul class="accordion-box style-two mb-30">
                                            <?php
                                                $i_sous = 0 ;
                                            ?>
                                            <?php $__currentLoopData = \App\Models\SousGamme::where('gamme_id',$gamme->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sous_gamme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                            <!--Accordion Block-->
                                            <li class="accordion block">
                                                <div class="acc-btn <?php if($i_sous == 0): ?> active <?php endif; ?>" style="padding: 20px;background: black;color:white;"><?php echo e($sous_gamme->title); ?></div>
                                                <div class="acc-content <?php if($i_sous == 0): ?> current <?php endif; ?>">
                                                    <div class="content">
                                                        <div class="row">
                                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $photos = explode(",",$item->photo);
                                                            ?>
                                                            <?php if($item->sous_gamme_id == $sous_gamme->id): ?>
                                                            <div class="col-lg-3 col-md-6 project-block " >
                                                                <div class="inner-box">
                                                                    <div class="image">
                                                                        <img src="<?php echo e($item->photo); ?>" style="height: 250px;object-fit: contain;" alt="">
                                                                    </div>
                                                                    <div class="overlay-content">
                                                                        <div>
                                                                            <h4><?php echo e($item->title); ?></h4>
                                                                        </div>
                                                                        <div class="link-btn"><a href="<?php echo e(route('product.detail',$item->slug)); ?>"><span class="flaticon-arrow-1"></span></a></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php
                                                            $i++ ;
                                                            ?>
                                                            <?php endif; ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>


                                            <?php
                                            $i_sous++ ;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                            </div>
                        </section>

                        <?php
                        $i++ ;
                        ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <?php endif; ?>



                </div>
            </div>
        </div>
    </section>

<?php else: ?>
<!-- Shop section -->
<section class="shop-section" style="padding: 0px 0 90px;">
    <div class="auto-container">
        <div class="row" id="product-data">
            <?php echo $__env->make('frontend.layouts._single-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
        <div class="ajax-load text-center" style="display: none">
            <img src="<?php echo e(asset('frontend/images/loading.gif')); ?>" style="width: 30%;" >
        </div>
        <?php if(count($products)==0): ?>
         <p>Il n'y a pas de produits</p>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>


    <?php if($categories->partenaire_ids != null): ?>
    <section class="cta-section-three" style="padding-top: 0;">
        <?php
        $partenaires = explode(',',$categories->partenaire_ids);
        ?>
        <div class="auto-container">
            <div class="content" >

                <?php $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $para): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <img src="<?php echo e(\App\Models\Brand::where('id',$para)->value('photo')); ?>" alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(count($gammes) == 0): ?>


    <script>
        function loadmoreData(page) {
            $.ajax({
                url: '?page='+page,
                type: 'GET',
                beforeSend: function () {
                    $('.ajax-load').show();
                },
            }).done(function(data){

                if(data.html == ''){
                    $('.ajax-load').html('');
                    return;
                }
                $('.ajax-load').hide();
                $('#product-data').append(data.html);
            }).fail(function(jqXHR, ajaxOptions, thrownError) {
                console.log('Somethong went wrong!! please try again');
            });
        }
        var page=1;

        $(window).scroll(function () {
            if($(window).scrollTop() +$(window).height()+420>=$(document).height()){
                page ++;
                loadmoreData(page);
            }
        });


    </script>


    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hpc\resources\views/frontend/pages/product/product-category.blade.php ENDPATH**/ ?>