

<?php $__env->startSection('content'); ?>
<?php if(isset($cart_data) && !empty($cart_data)): ?>
                    <?php if(Cookie::get('shopping_cart')): ?>
                        <?php $total="0" ?>
<div class="container" style="padding-top: 150px;padding-bottom: 80px">
<div class="my-properties">
    <table class="table-responsive">
        <thead>
            <tr>
                <th class="pl-2">Ma sélection</th>
                <th class="p-0"></th>
                <th>Supprimer</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $items_list = \App\Models\Product::find($data['item_id']);
            ?>
            <?php if($items_list): ?>


            <tr class="cartpage">
                <input type="hidden" class="product_id" value="<?php echo e($data['item_id']); ?>" >
                <td class="image myelist">
                    <a href="<?php echo e(route('product.detail',$items_list->slug)); ?>"><img alt="<?php echo e($items_list->title); ?>" src="<?php echo e($items_list->photo); ?>" class="img-fluid"></a>
                </td>
                <td>
                    <div class="inner">
                        <a href="<?php echo e(route('product.detail',$items_list->slug)); ?>"><h2><?php echo e($items_list->title); ?></h2></a>
                        <figure><i class="fa fa-map-marker"></i> <?php echo e($items_list->address); ?></figure>
                    </div>
                </td>
                <td class="actions" style="text-align: center;padding-right: 0">
                    <a class="delete_cart_data" href="#"><i class="far fa-trash-alt"></i></a>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
</div>
<?php endif; ?>
<?php else: ?>
<div style="padding-top: 150px;padding-bottom: 50px">
    <div class="container my-properties">
    <div class="row">
        <div class="col-md-12 mycard py-5 text-center">
            <div class="mycards">
                <h4>Votre liste de selection est vide.</h4>
                <a href="<?php echo e(route('tous.locaux')); ?>" class="btn btn-upper btn-primary outer-left-xs mt-5 button border" >Explorer les locaux</a>
            </div>
        </div>
    </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
// Delete Cart Data
    $(document).ready(function () {

        $('.delete_cart_data').click(function (e) {
            e.preventDefault();

            var product_id = $(this).closest(".cartpage").find('.product_id').val();
            var data = {
                '_token': $('input[name=_token]').val(),
                "product_id": product_id,
            };

         $(this).closest(".cartpage").remove();

            $.ajax({
                url: "<?php echo e(route('deleteselection.status')); ?>",
                type: 'GET',
                data: data,
                success: function (response) {
                   if(response.count == 0){
                       $('.my-properties').html('<div class="row"><div class="col-md-12 mycard py-5 text-center"><div class="mycards"><h4>Votre liste de selection est vide.</h4><a href="<?php echo e(route('tous.locaux')); ?>" class="btn btn-upper btn-primary outer-left-xs mt-5 button border">Explorer les locaux</a></div></div></div>');
                   }
                    // window.location.reload();
                }
            });
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/frontend/pages/selection/index.blade.php ENDPATH**/ ?>