<?php $__env->startSection('content'); ?>


<div id="wrapper">
    <div class="main-content">
        <div class="row small-spacing">
            <div class="col-xs-9">
                <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="box-content card white">
                    <h4 class="box-title">à propos</h4>
                    <!-- /.box-title -->
                    <div class="col-md-12">
                        <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <form action="<?php echo e(route('about.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Titre</label>
                                <input type="text" class="form-control" placeholder="Titre" value="<?php echo e($about->heading); ?>" name="heading">
                            </div>

                            <div class="m-t-20">
                                <label>Image</label>

                                <div class="input-group">
                                    <span class="input-group-btn">
                                      <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                      </a>
                                    </span>
                                    <input id="thumbnail" class="form-control" type="text" name="image" value="<?php echo e($about->image); ?>">
                                  </div>
                                <div id="holder" style="margin-top:15px;max-height:100px;">
                                    <img src="<?php echo e($about->image); ?>" style="margin-top:15px;max-height:100px;" />
                                </div>
                            </div>

                            <div class="m-t-20">
                                <label for="exampleInputEmail1">Description</label>

                                <textarea name="content" class="form-control" id="description" placeholder="Text...."><?php echo e($about->content); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Video</label>
                                <input type="text" class="form-control" placeholder="Lien Youtube de video" value="<?php echo e($about->video); ?>" name="video">
                            </div>
                            <hr style="color: black">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="text" class="form-control" placeholder="Email" value="<?php echo e($about->email); ?>" name="email">
                            </div>
                            <div class="form-group">
                                <label for="phone">Téléphone</label>
                                <input type="text" class="form-control" placeholder="Téléphone" value="<?php echo e($about->phone); ?>" name="phone">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Adresse</label>
                                <input type="text" class="form-control" placeholder="Adresse" value="<?php echo e($about->address); ?>" name="address">
                            </div>
                            <div class="form-group">
                                <label>Temps d'ouvrir</label>
                                <input type="time" class="form-control" placeholder="08:00H" value="<?php echo e($about->open_time); ?>" name="open_time">
                            </div>
                            <div class="form-group">
                                <label>Temps de fermer</label>
                                <input type="time" class="form-control" placeholder="17:00H" value="<?php echo e($about->close_time); ?>" name="close_time">
                            </div>
                            <div class="form-group">
                                <label>Facebook</label>
                                <input type="text" class="form-control" placeholder="https://facebook.com/Nomdevotrepagefb" value="<?php echo e($about->facebook); ?>" name="facebook">
                            </div>
                            <div class="form-group">
                                <label>Instagram</label>
                                <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepageinsta" value="<?php echo e($about->instagram); ?>" name="instagram">
                            </div>
                            <div class="form-group">
                                <label>Twitter</label>
                                <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepagetwitter" value="<?php echo e($about->twitter); ?>" name="twitter">
                            </div>
                            <div class="form-group">
                                <label>Linkedin</label>
                                <input type="text" class="form-control" placeholder="https://instagram.com/Nomdevotrepagelinkedin" value="<?php echo e($about->linkedin); ?>" name="linkedin">
                            </div>
                            <div class="form-group">
                                <label>Youtube</label>
                                <input type="text" class="form-control" placeholder="https://youtube.com/Nomdevotrechaineyoutube" value="<?php echo e($about->youtube); ?>" name="youtube">
                            </div>
                            <br>
                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Enregistrer</button>
                        </form>
                    </div>
                    <!-- /.card-content -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
<script>
    $(document).ready(function() {
        $('#description').summernote();
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/about/index.blade.php ENDPATH**/ ?>