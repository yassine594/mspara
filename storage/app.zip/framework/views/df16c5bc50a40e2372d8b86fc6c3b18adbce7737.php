<?php $__env->startSection('content'); ?>

<div id="wrapper">
	<div class="main-content">
        <div class="row small-spacing">
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content bg-success text-white">
					<div class="statistics-box with-icon">
						<i class="ico small fa fa-diamond"></i>
						<p class="text text-white"><a class="text-white" href="<?php echo e(route('local.index')); ?>">Local</a></p>
						<h2 class="counter"><?php echo e(\App\Models\Product::count()); ?></h2>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-lg-3 col-md-6 col-xs-12 -->
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content bg-info text-white">
					<div class="statistics-box with-icon">
						<i class="ico small fas fa-city"></i>
						<p class="text text-white"><a class="text-white" href="<?php echo e(route('localisation.index')); ?>">Ville</a></p>
						<h2 class="counter"><?php echo e(\App\Models\Category::where('is_parent',1)->count()); ?></h2>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-lg-3 col-md-6 col-xs-12 -->
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content bg-danger text-white">
					<div class="statistics-box with-icon">
						<i class="ico small fas fa-globe-europe"></i>
						<p class="text text-white"><a class="text-white" href="<?php echo e(route('devis.index')); ?>">devis</a></p>
						<h2 class="counter"><?php echo e(\App\Models\devis::count()); ?></h2>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-lg-3 col-md-6 col-xs-12 -->
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content bg-warning text-white">
					<div class="statistics-box with-icon">
						<i class="ico small fa fa-envelope"></i>
						<p class="text text-white"><a class="text-white" href="<?php echo e(route('contacts.index')); ?>">messages</a></p>
						<h2 class="counter"><?php echo e(\App\Models\Contact::count()); ?></h2>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-lg-3 col-md-6 col-xs-12 -->
		</div>
		<!-- .row -->


		<div class="row small-spacing">
			<div class="col-lg-12 col-xs-12">
				<div class="box-content">
					<h4 class="box-title">Dérnier Témoignage</h4>
					<div class="review-list">
                        <?php $__currentLoopData = \App\Models\Feedback::where('status','active')->orderby('id', 'DESC')->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="review-item">
							<div class="top">
								<div class="name"><?php echo e($rev->title); ?></div>
								<!-- /.name -->
								<div class="date"><?php echo e($rev->updated_at); ?></div>
								<!-- /.date -->
							</div>
							<!-- /.top -->
							<div class="desc"><?php echo e($rev->description); ?></div>
							<!-- /.desc -->
						</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<!-- /.review-item -->
					</div>
					<!-- /.review-list -->
				</div>
				<!-- /.box-content -->
			</div>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.main-content -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/index.blade.php ENDPATH**/ ?>