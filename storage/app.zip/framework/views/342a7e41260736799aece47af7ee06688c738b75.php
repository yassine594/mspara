<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 50px">
    <div class="card-content">
        <form action="<?php echo e(route('langs.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Code</label>
                <input type="text" class="form-control" placeholder="Code" value="<?php echo e(old('code')); ?>" name="code">
            </div>

            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" placeholder="Name" value="<?php echo e(old('name')); ?>" name="name">
            </div>
            <div class="m-t-20">
                <label>Photo</label>

                <div class="input-group">
                    <span class="input-group-btn">
                      <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                        <i class="fa fa-picture-o"></i> Choose
                      </a>
                    </span>
                    <input id="thumbnail" class="form-control" type="text" name="icon">
                  </div>
                <div id="holder" style="margin-top:15px;max-height:100px;"></div>
            </div>


            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Ajouter</button>
        </form>
    </div>
    <!-- <form method="POST" action="<?php echo e(route('langs.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <label>Code:</label>
                <input type="text" name="code" class="form-control Key" placeholder="Enter Key......">
            </div>

            <div class="col-md-4">
                <label>Name:</label>
                <input type="text" name="name" class="form-control Key" placeholder="Enter Value......">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-success">submit</button>
            </div>
        </div>
    </form> -->
    <h1>Languages</h1>

    <form method="POST" action="<?php echo e(route('languages.create')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <label>Key:</label>
                <input type="text" name="key" class="form-control Key" placeholder="Enter Key......">
            </div>

            <div class="col-md-4">
                <label>Value:</label>
                <input type="text" name="value" class="form-control Key" placeholder="Enter Value......">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-success">submit</button>
            </div>
        </div>
    </form>


    <table class="table table-hover table-bordered" style="margin-top: 22px;">
        <thead>
        <tr>
            <th>Key</th>
            <?php if($languages->count() > 0): ?>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($language->name); ?>(<?php echo e($language->code); ?>)</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <th width="80px;">Action</th>
        </tr>
        </thead>
        <tbody>
            <?php if($columnsCount > 0): ?>
                <?php $__currentLoopData = $columns[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $columnKey => $columnValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       <!-- <td><a href="#" class="translate-key" data-title="Enter Key" data-type="text" data-pk="<?php echo e($columnKey); ?>" data-url="<?php echo e(route('languages.update.json.key')); ?>"><?php echo e($columnKey); ?></a></td> -->
                       <td><a data-type="text"><?php echo e($columnKey); ?></a></td>
                        <?php for($i=1; $i<=$columnsCount; ++$i): ?>
                        <td><a href="#" data-title="Enter Translate" class="translate" data-code="<?php echo e($columns[$i]['lang']); ?>" data-type="textarea" data-pk="<?php echo e($columnKey); ?>" data-url="<?php echo e(route('languages.update.json')); ?>"><?php echo e(isset($columns[$i]['data'][$columnKey]) ? $columns[$i]['data'][$columnKey] : ''); ?></a></td>
                        <?php endfor; ?>
                        <td><button data-action="<?php echo e(route('languages.destroy', $columnKey)); ?>" class="btn btn-danger btn-xs remove-key">DeleteIT</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.translate').editable({
        params: function(params) {
            params.code = $(this).editable().data('code');
            return params;
        }
    });


    $('.translate-key').editable({
        validate: function(value) {
            if($.trim(value) == '') {
                return 'Key is must required';
            }
        }
    });


    $('body').on('click', '.remove-key', function(){
        var cObj = $(this);
        if (confirm("Are you sure want to remove this stuff?")) {
            $.ajax({
                url: cObj.data('action'),
                method: 'DELETE',
                success: function(data) {
                    cObj.parents("tr").remove();
                    alert("Your imaginary file has deleted.");
                }
            });
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hengxin\homes\resources\views/backend/languages/languages.blade.php ENDPATH**/ ?>